import { idbGet, idbSet } from "./idb";

export type SurahMeta = {
  n: number;
  name: string;
  en: string;
  type: "makki" | "madani";
  ayahs: number;
  page: number;
  juz: number;
};

export type Ayah = {
  a: number;
  g: number;
  t: string;
  p: number;
  j: number;
  h: number;
};

export type QuranMeta = {
  textSource: string;
  tafsirSource: string;
  enSource: string;
  nlSource: string;
  counts: { surahs: number; ayahs: number; pages: number; juz: number };
  basmala: string;
  surahs: SurahMeta[];
  pages: [number, number][];
  juz: [number, number][];
  quarters: [number, number][];
  daily: { s: number; a: number; t: string }[];
};

const memory = new Map<string, unknown>();
const inflight = new Map<string, Promise<unknown>>();

export async function loadJson<T>(url: string): Promise<T> {
  const hit = memory.get(url);
  if (hit) return hit as T;
  const pending = inflight.get(url);
  if (pending) return pending as Promise<T>;
  const task = (async () => {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("تعذر التحميل");
      const data = (await res.json()) as T;
      void idbSet("text", url, data).catch(() => undefined);
      memory.set(url, data);
      return data;
    } catch (error) {
      const cached = await idbGet<T>("text", url);
      if (cached) {
        memory.set(url, cached);
        return cached;
      }
      throw error;
    }
  })();
  inflight.set(url, task);
  try {
    return await task;
  } finally {
    inflight.delete(url);
  }
}

export function loadMeta() {
  return loadJson<QuranMeta>("/data/meta.json");
}

export function loadSurah(n: number) {
  return loadJson<{ ayahs: Ayah[] }>(`/data/q/${n}.json`);
}

export function loadTafsir(n: number) {
  return loadJson<string[]>(`/data/tf/${n}.json`);
}

export function loadNorm() {
  return loadJson<string[][]>("/data/norm.json");
}

export function loadTranslation(lang: "en" | "nl") {
  return loadJson<string[][]>(lang === "en" ? "/data/en.json" : "/data/nl.json");
}

export function surahLabel(name: string) {
  return name.replace(/^سُورَةُ\s*/, "");
}

export function toArabicDigits(value: number | string) {
  return String(value).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)] ?? d);
}

export function globalOf(surah: number, ayah: number, surahs: SurahMeta[]) {
  let g = ayah;
  for (let i = 0; i < surah - 1; i++) g += surahs[i]?.ayahs ?? 0;
  return g;
}

export function locateGlobal(g: number, surahs: SurahMeta[]) {
  let left = g;
  for (const s of surahs) {
    if (left <= s.ayahs) return { s: s.n, a: left };
    left -= s.ayahs;
  }
  return { s: 114, a: surahs[113]?.ayahs ?? 6 };
}

export function normalizeArabic(input: string) {
  return input
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED\u0640\uFEFF]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ي")
    .replace(/[^\u0600-\u06FF0-9\s:]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function parseDigits(input: string) {
  const map = "٠١٢٣٤٥٦٧٨٩";
  return input.replace(/[٠-٩]/g, (d) => String(map.indexOf(d)));
}

export function dayOfYear(date = new Date()) {
  const start = Date.UTC(date.getUTCFullYear(), 0, 0);
  return Math.floor((date.getTime() - start) / 86_400_000);
}

const TEXT_URLS = ["/data/meta.json", "/data/norm.json", "/data/en.json", "/data/nl.json"];

export function allTextUrls() {
  const urls = [...TEXT_URLS];
  for (let i = 1; i <= 114; i++) {
    urls.push(`/data/q/${i}.json`, `/data/tf/${i}.json`);
  }
  return urls;
}

export async function prepareOffline(onProgress?: (done: number, total: number) => void) {
  const urls = allTextUrls();
  let done = 0;
  for (const url of urls) {
    await loadJson(url);
    done += 1;
    onProgress?.(done, urls.length);
  }
}
