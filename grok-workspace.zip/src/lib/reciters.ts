export const RECITERS = [
  { id: "ar.alafasy", name: "مشاري راشد العفاسي" },
  { id: "ar.husary", name: "محمود خليل الحصري" },
  { id: "ar.abdulbasitmurattal", name: "عبد الباسط عبد الصمد" },
  { id: "ar.shaatree", name: "أبو بكر الشاطري" },
  { id: "ar.ahmedajamy", name: "أحمد بن علي العجمي" },
] as const;

export type ReciterId = (typeof RECITERS)[number]["id"];

export function reciterName(id: string) {
  return RECITERS.find((item) => item.id === id)?.name ?? id;
}

export function audioUrl(reciter: string, globalAyah: number) {
  return `https://cdn.islamic.network/quran/audio/64/${reciter}/${globalAyah}.mp3`;
}

/** Rough size at 64 kbps, from sampled files. Not an exact byte count. */
export function estimateBytes(ayahCount: number) {
  return ayahCount * 52_000;
}

export function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} ك.ب`;
  return `${(bytes / (1024 * 1024)).toFixed(bytes > 100 * 1024 * 1024 ? 0 : 1)} م.ب`;
}
