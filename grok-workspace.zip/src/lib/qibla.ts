const KAABA_LAT = 21.4225;
const KAABA_LON = 39.8262;

export function qiblaBearing(lat: number, lon: number) {
  const φ1 = (lat * Math.PI) / 180;
  const λ1 = (lon * Math.PI) / 180;
  const φ2 = (KAABA_LAT * Math.PI) / 180;
  const λ2 = (KAABA_LON * Math.PI) / 180;
  const y = Math.sin(λ2 - λ1) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(λ2 - λ1);
  return (Math.atan2(y, x) * 180) / Math.PI;
}

export function normalizeDeg(value: number) {
  return ((value % 360) + 360) % 360;
}

export const CITIES: { name: string; lat: number; lon: number }[] = [
  { name: "مكة المكرمة", lat: 21.4225, lon: 39.8262 },
  { name: "المدينة المنورة", lat: 24.4672, lon: 39.6111 },
  { name: "الرياض", lat: 24.7136, lon: 46.6753 },
  { name: "جدة", lat: 21.5433, lon: 39.1728 },
  { name: "الدمام", lat: 26.4207, lon: 50.0888 },
  { name: "دبي", lat: 25.2048, lon: 55.2708 },
  { name: "أبوظبي", lat: 24.4539, lon: 54.3773 },
  { name: "الدوحة", lat: 25.2854, lon: 51.531 },
  { name: "الكويت", lat: 29.3759, lon: 47.9774 },
  { name: "المنامة", lat: 26.2235, lon: 50.5876 },
  { name: "مسقط", lat: 23.588, lon: 58.3829 },
  { name: "صنعاء", lat: 15.3694, lon: 44.191 },
  { name: "عمّان", lat: 31.9539, lon: 35.9106 },
  { name: "القدس", lat: 31.7683, lon: 35.2137 },
  { name: "دمشق", lat: 33.5138, lon: 36.2765 },
  { name: "بيروت", lat: 33.8938, lon: 35.5018 },
  { name: "بغداد", lat: 33.3152, lon: 44.3661 },
  { name: "القاهرة", lat: 30.0444, lon: 31.2357 },
  { name: "الإسكندرية", lat: 31.2001, lon: 29.9187 },
  { name: "الخرطوم", lat: 15.5007, lon: 32.5599 },
  { name: "تونس", lat: 36.8065, lon: 10.1815 },
  { name: "الجزائر", lat: 36.7538, lon: 3.0588 },
  { name: "الرباط", lat: 34.0209, lon: -6.8416 },
  { name: "طرابلس", lat: 32.8872, lon: 13.1913 },
  { name: "إسطنبول", lat: 41.0082, lon: 28.9784 },
  { name: "جاكرتا", lat: -6.2088, lon: 106.8456 },
  { name: "كوالالمبور", lat: 3.139, lon: 101.6869 },
  { name: "لندن", lat: 51.5074, lon: -0.1278 },
  { name: "أمستردام", lat: 52.3676, lon: 4.9041 },
  { name: "باريس", lat: 48.8566, lon: 2.3522 },
  { name: "نيويورك", lat: 40.7128, lon: -74.006 },
];
