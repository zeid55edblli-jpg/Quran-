import { create } from "zustand";
import { idbGet } from "./idb";
import { globalOf, loadMeta, loadSurah, locateGlobal, surahLabel } from "./quran";
import { audioUrl, reciterName } from "./reciters";
import { useApp } from "./store";

type PlayerState = {
  surah: number;
  ayah: number;
  playing: boolean;
  current: number;
  duration: number;
  error: string;
  setClock: (current: number, duration: number) => void;
  setPlaying: (playing: boolean) => void;
  play: (surah: number, ayah: number) => Promise<void>;
  toggle: () => void;
  seek: (ratio: number) => void;
  next: () => Promise<void>;
  prev: () => Promise<void>;
  onEnded: () => Promise<void>;
};

let audio: HTMLAudioElement | null = null;
let objectUrl = "";

function element() {
  if (typeof window === "undefined") return null;
  if (!audio) {
    audio = new Audio();
    audio.preload = "auto";
    audio.setAttribute("playsinline", "true");
  }
  return audio;
}

function releaseUrl() {
  if (objectUrl) {
    URL.revokeObjectURL(objectUrl);
    objectUrl = "";
  }
}

async function sourceFor(reciter: string, globalAyah: number) {
  const blob = await idbGet<Blob>("audio", `${reciter}:${globalAyah}`);
  if (blob instanceof Blob) {
    releaseUrl();
    objectUrl = URL.createObjectURL(blob);
    return objectUrl;
  }
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    throw new Error("هذه التلاوة غير محفوظة على الجهاز، ويحتاج تنزيلها أو تشغيلها إلى اتصال.");
  }
  releaseUrl();
  return audioUrl(reciter, globalAyah);
}

function publishSession(surahName: string, ayah: number, reciter: string) {
  if (!("mediaSession" in navigator)) return;
  navigator.mediaSession.metadata = new MediaMetadata({
    title: `${surahName} — الآية ${ayah}`,
    artist: reciterName(reciter),
    album: "نور القرآن الكريم",
  });
  navigator.mediaSession.setActionHandler("play", () => element()?.play());
  navigator.mediaSession.setActionHandler("pause", () => element()?.pause());
  navigator.mediaSession.setActionHandler("nexttrack", () => void usePlayer.getState().next());
  navigator.mediaSession.setActionHandler("previoustrack", () => void usePlayer.getState().prev());
}

export const usePlayer = create<PlayerState>((set, get) => ({
  surah: 0,
  ayah: 0,
  playing: false,
  current: 0,
  duration: 0,
  error: "",
  setClock: (current, duration) => set({ current, duration: Number.isFinite(duration) ? duration : 0 }),
  setPlaying: (playing) => set({ playing }),
  play: async (surah, ayah) => {
    const node = element();
    if (!node) return;
    const app = useApp.getState();
    const meta = await loadMeta();
    const surahMeta = meta.surahs[surah - 1];
    if (!surahMeta || ayah < 1 || ayah > surahMeta.ayahs) return;
    const globalAyah = globalOf(surah, ayah, meta.surahs);
    set({ error: "", surah, ayah, current: 0, duration: 0 });
    try {
      node.src = await sourceFor(app.reciter, globalAyah);
      node.playbackRate = app.rate;
      await node.play();
      set({ playing: true });
      app.setLastListen({ s: surah, a: ayah, reciter: app.reciter });
      publishSession(surahLabel(surahMeta.name), ayah, app.reciter);
    } catch (error) {
      set({
        playing: false,
        error: error instanceof Error ? error.message : "تعذر تشغيل التلاوة.",
      });
    }
  },
  toggle: () => {
    const node = element();
    if (!node || !get().surah) return;
    if (node.paused) void node.play();
    else node.pause();
  },
  seek: (ratio) => {
    const node = element();
    if (!node || !Number.isFinite(node.duration)) return;
    node.currentTime = Math.min(node.duration, Math.max(0, ratio * node.duration));
  },
  next: async () => {
    const { surah, ayah } = get();
    if (!surah) return;
    const meta = await loadMeta();
    const count = meta.surahs[surah - 1]?.ayahs ?? 0;
    if (ayah < count) await get().play(surah, ayah + 1);
    else if (surah < 114) await get().play(surah + 1, 1);
  },
  prev: async () => {
    const { surah, ayah } = get();
    if (!surah) return;
    if (ayah > 1) await get().play(surah, ayah - 1);
    else if (surah > 1) {
      const meta = await loadMeta();
      await get().play(surah - 1, meta.surahs[surah - 2]?.ayahs ?? 1);
    }
  },
  onEnded: async () => {
    const repeat = useApp.getState().repeat;
    const { surah, ayah } = get();
    if (repeat === "ayah") {
      await get().play(surah, ayah);
      return;
    }
    const meta = await loadMeta();
    const count = meta.surahs[surah - 1]?.ayahs ?? 0;
    if (repeat === "surah" && ayah >= count) {
      await get().play(surah, 1);
      return;
    }
    await get().next();
  },
}));

export function bindAudio() {
  const node = element();
  if (!node) return () => undefined;
  const onTime = () => usePlayer.getState().setClock(node.currentTime, node.duration);
  const onPlay = () => usePlayer.getState().setPlaying(true);
  const onPause = () => usePlayer.getState().setPlaying(false);
  const onEnded = () => void usePlayer.getState().onEnded();
  const onError = () => {
    usePlayer.getState().setPlaying(false);
    usePlayer.setState({
      error: "تعذر تشغيل الملف. إن لم يكن محفوظًا على الجهاز فالتشغيل يحتاج اتصالًا.",
    });
  };
  node.addEventListener("timeupdate", onTime);
  node.addEventListener("play", onPlay);
  node.addEventListener("pause", onPause);
  node.addEventListener("ended", onEnded);
  node.addEventListener("error", onError);
  return () => {
    node.removeEventListener("timeupdate", onTime);
    node.removeEventListener("play", onPlay);
    node.removeEventListener("pause", onPause);
    node.removeEventListener("ended", onEnded);
    node.removeEventListener("error", onError);
  };
}

export async function ayahText(surah: number, ayah: number) {
  const data = await loadSurah(surah);
  return data.ayahs.find((item) => item.a === ayah)?.t ?? "";
}

export function setPlaybackRate(rate: number) {
  if (audio) audio.playbackRate = rate;
}
