import { create } from "zustand";
import { idbDeletePrefix, idbSet } from "./idb";
import { globalOf, loadMeta } from "./quran";
import { audioUrl } from "./reciters";
import { useApp } from "./store";

type Job = {
  key: string;
  label: string;
  done: number;
  total: number;
  bytes: number;
  paused: boolean;
  error: string;
};

type DownloadState = {
  job: Job | null;
  startSurah: (reciter: string, surah: number) => void;
  startAll: (reciter: string) => void;
  pause: () => void;
  resume: () => void;
  clearReciter: (reciter: string) => Promise<void>;
};

const controllers = new Map<string, AbortController>();

async function fetchAyah(reciter: string, globalAyah: number, signal: AbortSignal) {
  const res = await fetch(audioUrl(reciter, globalAyah), { signal });
  if (!res.ok) throw new Error("تعذر تنزيل المقطع");
  const blob = await res.blob();
  await idbSet("audio", `${reciter}:${globalAyah}`, blob);
  return blob.size;
}

async function runRange(
  reciter: string,
  surah: number,
  fromAyah: number,
  signal: AbortSignal,
  onAyah: (bytes: number) => void,
) {
  const meta = await loadMeta();
  const info = meta.surahs[surah - 1];
  if (!info) return;
  for (let ayah = fromAyah; ayah <= info.ayahs; ayah++) {
    if (signal.aborted) throw new DOMException("paused", "AbortError");
    const size = await fetchAyah(reciter, globalOf(surah, ayah, meta.surahs), signal);
    useApp.getState().setAudioSaved(`${reciter}:${surah}`, ayah);
    onAyah(size);
  }
}

export const useDownloads = create<DownloadState>((set, get) => ({
  job: null,
  startSurah: (reciter, surah) => {
    const saved = useApp.getState().audioSaved[`${reciter}:${surah}`] ?? 0;
    void startJob(reciter, [{ surah, from: saved + 1 }], `سورة ${surah}`, set, get);
  },
  startAll: (reciter) => {
    const saved = useApp.getState().audioSaved;
    const plan: { surah: number; from: number }[] = [];
    for (let surah = 1; surah <= 114; surah++) {
      plan.push({ surah, from: (saved[`${reciter}:${surah}`] ?? 0) + 1 });
    }
    void startJob(reciter, plan, "كل السور", set, get);
  },
  pause: () => {
    const job = get().job;
    if (!job) return;
    controllers.get(job.key)?.abort();
    set({ job: { ...job, paused: true } });
  },
  resume: () => {
    const job = get().job;
    if (!job?.paused) return;
    const reciter = job.key.split(":")[0] ?? "";
    if (job.label === "كل السور") get().startAll(reciter);
    else {
      const surah = Number(job.key.split(":")[1]);
      get().startSurah(reciter, surah);
    }
  },
  clearReciter: async (reciter) => {
    controllers.get(get().job?.key ?? "")?.abort();
    await idbDeletePrefix("audio", `${reciter}:`);
    const audioSaved = { ...useApp.getState().audioSaved };
    for (const key of Object.keys(audioSaved)) {
      if (key.startsWith(`${reciter}:`)) delete audioSaved[key];
    }
    useApp.getState().patch({ audioSaved });
    set({ job: null });
  },
}));

async function startJob(
  reciter: string,
  plan: { surah: number; from: number }[],
  label: string,
  set: (partial: Partial<DownloadState> | ((state: DownloadState) => Partial<DownloadState>)) => void,
  get: () => DownloadState,
) {
  const prev = get().job;
  if (prev) controllers.get(prev.key)?.abort();
  const meta = await loadMeta();
  const total = plan.reduce((sum, item) => {
    const ayahs = meta.surahs[item.surah - 1]?.ayahs ?? 0;
    return sum + Math.max(0, ayahs - item.from + 1);
  }, 0);
  if (total === 0) {
    useApp.getState().showToast("هذه التلاوة محفوظة بالفعل");
    return;
  }
  const key = label === "كل السور" ? `${reciter}:all` : `${reciter}:${plan[0]?.surah ?? 0}`;
  const ctrl = new AbortController();
  controllers.set(key, ctrl);
  set({ job: { key, label, done: 0, total, bytes: 0, paused: false, error: "" } });
  try {
    for (const item of plan) {
      const ayahs = meta.surahs[item.surah - 1]?.ayahs ?? 0;
      if (item.from > ayahs) continue;
      await runRange(reciter, item.surah, item.from, ctrl.signal, (bytes) => {
        const job = get().job;
        if (!job || job.key !== key) return;
        set({ job: { ...job, done: job.done + 1, bytes: job.bytes + bytes } });
      });
    }
    set({ job: null });
    useApp.getState().showToast("اكتمل التنزيل");
  } catch (error) {
    if (ctrl.signal.aborted) return;
    const job = get().job;
    if (!job) return;
    set({
      job: {
        ...job,
        paused: true,
        error: error instanceof Error ? error.message : "توقف التنزيل",
      },
    });
  } finally {
    controllers.delete(key);
  }
}
