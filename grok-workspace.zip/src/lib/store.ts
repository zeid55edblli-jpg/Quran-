import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Fav =
  | { kind: "ayah"; s: number; a: number }
  | { kind: "surah"; s: number }
  | { kind: "dhikr"; id: string }
  | { kind: "tafsir"; s: number; a: number }
  | { kind: "audio"; s: number; reciter: string };

export type Reminder = { enabled: boolean; time: string };

type Place = { lat: number; lon: number; label: string };

type LastPos = { s: number; a: number; p: number; j: number };

type AppState = {
  seenSplash: boolean;
  appearance: "night" | "day";
  mushafTheme: "day" | "night";
  fontScale: number;
  translation: "off" | "en" | "nl";
  reciter: string;
  rate: number;
  repeat: "off" | "ayah" | "surah";
  reminders: { read: Reminder; morning: Reminder; evening: Reminder; resume: Reminder };
  reminderStamp: string;
  searchHistoryOn: boolean;
  searchHistory: string[];
  lastRead: LastPos | null;
  lastListen: { s: number; a: number; reciter: string } | null;
  favorites: Fav[];
  audioSaved: Record<string, number>;
  place: Place | null;
  dhikrCounts: Record<string, number>;
  toast: string;
  markSplash: () => void;
  patch: (partial: Partial<AppState>) => void;
  setLastRead: (pos: LastPos) => void;
  setLastListen: (pos: { s: number; a: number; reciter: string }) => void;
  toggleFav: (fav: Fav) => void;
  hasFav: (fav: Fav) => boolean;
  pushSearch: (q: string) => void;
  clearSearch: () => void;
  setAudioSaved: (key: string, count: number) => void;
  setDhikr: (id: string, count: number) => void;
  showToast: (message: string) => void;
};

function sameFav(a: Fav, b: Fav) {
  if (a.kind !== b.kind) return false;
  if (a.kind === "dhikr" && b.kind === "dhikr") return a.id === b.id;
  if (a.kind === "surah" && b.kind === "surah") return a.s === b.s;
  if (a.kind === "audio" && b.kind === "audio") return a.s === b.s && a.reciter === b.reciter;
  if ("a" in a && "a" in b) return a.s === b.s && a.a === b.a;
  return false;
}

let toastTimer: ReturnType<typeof setTimeout> | undefined;

export const useApp = create<AppState>()(
  persist(
    (set, get) => ({
      seenSplash: false,
      appearance: "night",
      mushafTheme: "day",
      fontScale: 1,
      translation: "off",
      reciter: "ar.alafasy",
      rate: 1,
      repeat: "off",
      reminders: {
        read: { enabled: false, time: "08:00" },
        morning: { enabled: false, time: "06:30" },
        evening: { enabled: false, time: "17:30" },
        resume: { enabled: false, time: "21:00" },
      },
      reminderStamp: "",
      searchHistoryOn: true,
      searchHistory: [],
      lastRead: null,
      lastListen: null,
      favorites: [],
      audioSaved: {},
      place: null,
      dhikrCounts: {},
      toast: "",
      markSplash: () => set({ seenSplash: true }),
      patch: (partial) => set(partial),
      setLastRead: (pos) => set({ lastRead: pos }),
      setLastListen: (pos) => set({ lastListen: pos }),
      toggleFav: (fav) => {
        const list = get().favorites;
        const exists = list.some((item) => sameFav(item, fav));
        set({ favorites: exists ? list.filter((item) => !sameFav(item, fav)) : [fav, ...list] });
      },
      hasFav: (fav) => get().favorites.some((item) => sameFav(item, fav)),
      pushSearch: (q) => {
        const query = q.trim();
        if (!query || !get().searchHistoryOn) return;
        const next = [query, ...get().searchHistory.filter((item) => item !== query)].slice(0, 12);
        set({ searchHistory: next });
      },
      clearSearch: () => set({ searchHistory: [] }),
      setAudioSaved: (key, count) => set({ audioSaved: { ...get().audioSaved, [key]: count } }),
      setDhikr: (id, count) => set({ dhikrCounts: { ...get().dhikrCounts, [id]: count } }),
      showToast: (message) => {
        set({ toast: message });
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(() => set({ toast: "" }), 1800);
      },
    }),
    {
      name: "noor-al-quran",
      partialize: (state) => ({
        seenSplash: state.seenSplash,
        appearance: state.appearance,
        mushafTheme: state.mushafTheme,
        fontScale: state.fontScale,
        translation: state.translation,
        reciter: state.reciter,
        rate: state.rate,
        repeat: state.repeat,
        reminders: state.reminders,
        reminderStamp: state.reminderStamp,
        searchHistoryOn: state.searchHistoryOn,
        searchHistory: state.searchHistory,
        lastRead: state.lastRead,
        lastListen: state.lastListen,
        favorites: state.favorites,
        audioSaved: state.audioSaved,
        place: state.place,
        dhikrCounts: state.dhikrCounts,
      }),
    },
  ),
);
