import { useQuery } from "@tanstack/react-query";
import { Link, createFileRoute } from "@tanstack/react-router";
import { Bookmark, Copy, Heart, Minus, Play, Plus, Share2, SunMoon } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { loadMeta, loadSurah, loadTranslation, surahLabel, toArabicDigits, type Ayah } from "@/lib/quran";
import { usePlayer } from "@/lib/player";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/mushaf/$surah")({
  validateSearch: (search: Record<string, unknown>) => ({
    ayah: Number(search.ayah) || 1,
  }),
  component: ReaderPage,
});

async function copyText(text: string) {
  await navigator.clipboard.writeText(text);
  useApp.getState().showToast("تم النسخ");
}

async function shareText(text: string) {
  if (navigator.share) {
    try {
      await navigator.share({ title: "نور القرآن الكريم", text });
      return;
    } catch {
      return;
    }
  }
  await copyText(text);
}

function ReaderPage() {
  const { surah: surahParam } = Route.useParams();
  const { ayah: initialAyah } = Route.useSearch();
  const surah = Number(surahParam);
  const meta = useQuery({ queryKey: ["meta"], queryFn: loadMeta });
  const data = useQuery({
    queryKey: ["surah", surah],
    queryFn: () => loadSurah(surah),
    enabled: surah >= 1 && surah <= 114,
  });
  const translation = useApp((s) => s.translation);
  const trans = useQuery({
    queryKey: ["tr", translation],
    queryFn: () => loadTranslation(translation === "nl" ? "nl" : "en"),
    enabled: translation !== "off",
  });
  const theme = useApp((s) => s.mushafTheme);
  const scale = useApp((s) => s.fontScale);
  const patch = useApp((s) => s.patch);
  const setLastRead = useApp((s) => s.setLastRead);
  const toggleFav = useApp((s) => s.toggleFav);
  const hasFav = useApp((s) => s.hasFav);
  const play = usePlayer((s) => s.play);
  const [selected, setSelected] = useState(initialAyah);
  const scroller = useRef<HTMLDivElement>(null);
  const info = meta.data?.surahs[surah - 1];

  useEffect(() => {
    const node = document.getElementById(`ayah-${initialAyah}`);
    node?.scrollIntoView({ block: "center" });
  }, [initialAyah, data.data]);

  useEffect(() => {
    const root = scroller.current;
    if (!root || !info) return;
    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (!visible) return;
        const ayah = Number((visible.target as HTMLElement).dataset.ayah);
        const page = Number((visible.target as HTMLElement).dataset.page);
        const juz = Number((visible.target as HTMLElement).dataset.juz);
        if (!ayah) return;
        setLastRead({ s: surah, a: ayah, p: page, j: juz });
      },
      { root, threshold: 0.6 },
    );
    root.querySelectorAll("[data-ayah]").forEach((node) => obs.observe(node));
    return () => obs.disconnect();
  }, [data.data, info, setLastRead, surah]);

  if (!info && meta.isSuccess) {
    return (
      <main className="p-6 text-center">
        <p>السورة غير موجودة.</p>
        <Link to="/mushaf" className="gold-btn mt-4">
          العودة للسور
        </Link>
      </main>
    );
  }

  return (
    <main className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/92 px-3 py-2 backdrop-blur">
        <div className="flex items-center gap-1">
          <Link to="/mushaf" className="icon-btn" aria-label="السور">
            السور
          </Link>
          <div className="min-w-0 flex-1 text-center">
            <h1 className="truncate font-bold text-gold">{info ? surahLabel(info.name) : "…"}</h1>
            {info ? (
              <p className="text-xs text-muted">
                {info.type === "makki" ? "مكية" : "مدنية"} · {toArabicDigits(info.ayahs)} آية
              </p>
            ) : null}
          </div>
          <button
            type="button"
            className="icon-btn"
            aria-label="وضع الصفحة"
            onClick={() => patch({ mushafTheme: theme === "day" ? "night" : "day" })}
          >
            <SunMoon />
          </button>
        </div>
        <div className="mt-1 flex items-center justify-center gap-2">
          <button type="button" className="icon-btn" aria-label="تصغير الخط" onClick={() => patch({ fontScale: Math.max(0.85, scale - 0.1) })}>
            <Minus />
          </button>
          <span className="text-xs text-muted">حجم الخط</span>
          <button type="button" className="icon-btn" aria-label="تكبير الخط" onClick={() => patch({ fontScale: Math.min(1.7, scale + 0.1) })}>
            <Plus />
          </button>
          {info ? (
            <button
              type="button"
              className={`text-sm ${hasFav({ kind: "surah", s: surah }) ? "text-gold" : "text-muted"}`}
              onClick={() => toggleFav({ kind: "surah", s: surah })}
            >
              <Bookmark className="inline" size={16} /> السورة
            </button>
          ) : null}
        </div>
      </header>

      <div ref={scroller} className={`mx-3 my-3 flex-1 overflow-auto rounded-card px-4 py-5 ${theme === "day" ? "mushaf-day" : "mushaf-night"}`}>
        {info && surah !== 9 && surah !== 1 && meta.data ? (
          <p className="quran-text mb-4 text-center text-gold" style={{ fontSize: `${1.7 * scale}rem` }}>
            {meta.data.basmala}
          </p>
        ) : null}
        {data.isError ? <p className="text-center">تعذر فتح السورة دون اتصال إن لم تُحفظ من قبل.</p> : null}
        <div className="quran-text" style={{ fontSize: `${1.55 * scale}rem` }}>
          {data.data?.ayahs.map((ayah) => (
            <AyahBlock
              key={ayah.a}
              ayah={ayah}
              surah={surah}
              surahName={info ? surahLabel(info.name) : ""}
              selected={selected === ayah.a}
              translation={translation === "off" ? "" : (trans.data?.[surah - 1]?.[ayah.a - 1] ?? "")}
              onSelect={() => setSelected(ayah.a)}
              onPlay={() => void play(surah, ayah.a)}
              faved={hasFav({ kind: "ayah", s: surah, a: ayah.a })}
              onFav={() => toggleFav({ kind: "ayah", s: surah, a: ayah.a })}
            />
          ))}
        </div>
      </div>

      <div className="flex gap-2 px-3 pb-3">
        {surah > 1 ? (
          <Link to="/mushaf/$surah" params={{ surah: String(surah - 1) }} search={{ ayah: 1 }} className="ghost-btn flex-1">
            السورة السابقة
          </Link>
        ) : (
          <span className="flex-1" />
        )}
        {surah < 114 ? (
          <Link to="/mushaf/$surah" params={{ surah: String(surah + 1) }} search={{ ayah: 1 }} className="ghost-btn flex-1">
            السورة التالية
          </Link>
        ) : null}
      </div>
    </main>
  );
}

function AyahBlock({
  ayah,
  surah,
  surahName,
  selected,
  translation,
  onSelect,
  onPlay,
  faved,
  onFav,
}: {
  ayah: Ayah;
  surah: number;
  surahName: string;
  selected: boolean;
  translation: string;
  onSelect: () => void;
  onPlay: () => void;
  faved: boolean;
  onFav: () => void;
}) {
  const hizb = Math.ceil(ayah.h / 4);
  const quarter = ((ayah.h - 1) % 4) + 1;
  const shareBody = `${ayah.t} ﴿${surahName}: ${ayah.a}﴾`;
  return (
    <article id={`ayah-${ayah.a}`} data-ayah={ayah.a} data-page={ayah.p} data-juz={ayah.j} className="mb-3">
      <button type="button" className="w-full text-right" onClick={onSelect}>
        <span>{ayah.t}</span>{" "}
        <span className="ayah-mark">{toArabicDigits(ayah.a)}</span>
      </button>
      {translation ? <p className="mt-2 text-sm leading-relaxed opacity-80" style={{ fontFamily: "Cairo, sans-serif" }}>{translation}</p> : null}
      {selected ? (
        <div className="mt-2 flex flex-wrap gap-2 text-sm" style={{ fontFamily: "Cairo, sans-serif" }}>
          <button type="button" className="ghost-btn" onClick={onPlay}>
            <Play size={16} /> استماع
          </button>
          <button type="button" className="ghost-btn" onClick={() => void copyText(shareBody)}>
            <Copy size={16} /> نسخ
          </button>
          <button type="button" className="ghost-btn" onClick={() => void shareText(shareBody)}>
            <Share2 size={16} /> مشاركة
          </button>
          <button type="button" className="ghost-btn" onClick={onFav}>
            <Heart size={16} /> {faved ? "في المفضلة" : "مفضلة"}
          </button>
          <Link to="/tafsir" search={{ s: surah, a: ayah.a }} className="ghost-btn">
            تفسير
          </Link>
          <span className="self-center text-xs opacity-70">
            ص {toArabicDigits(ayah.p)} · ج {toArabicDigits(ayah.j)} · حزب {toArabicDigits(hizb)} ربع {toArabicDigits(quarter)}
          </span>
        </div>
      ) : null}
    </article>
  );
}
