import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { useState } from "react";
import { Screen, TopBar } from "@/components/bits";
import { loadMeta, loadSurah, loadTranslation, surahLabel, toArabicDigits } from "@/lib/quran";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/translate")({
  component: TranslatePage,
});

function TranslatePage() {
  const meta = useQuery({ queryKey: ["meta"], queryFn: loadMeta });
  const [surah, setSurah] = useState(1);
  const [ayah, setAyah] = useState(1);
  const lang = useApp((s) => s.translation);
  const active = lang === "off" ? "en" : lang;
  const patch = useApp((s) => s.patch);
  const toggle = useApp((s) => s.toggleFav);
  const has = useApp((s) => s.hasFav);
  const q = useQuery({ queryKey: ["surah", surah], queryFn: () => loadSurah(surah) });
  const tr = useQuery({ queryKey: ["tr", active], queryFn: () => loadTranslation(active) });
  const info = meta.data?.surahs[surah - 1];
  const safe = info ? Math.min(info.ayahs, Math.max(1, ayah)) : 1;
  const text = q.data?.ayahs[safe - 1]?.t ?? "";
  const meaning = tr.data?.[surah - 1]?.[safe - 1] ?? "";

  return (
    <main>
      <TopBar title="ترجمة المعاني" backTo="/more" />
      <Screen className="space-y-3">
        <p className="card px-4 py-3 text-sm leading-relaxed text-muted">
          النص العربي هو القرآن. ما يظهر بالإنجليزية أو الهولندية ترجمة لمعانيه، وليس القرآن نفسه.
          {active === "en" ? ` المصدر: ${meta.data?.enSource ?? ""}` : ` المصدر: ${meta.data?.nlSource ?? ""}`}
        </p>
        <div className="flex gap-2">
          <button type="button" className={`ghost-btn ${active === "en" ? "border-gold text-gold" : ""}`} onClick={() => patch({ translation: "en" })}>
            English
          </button>
          <button type="button" className={`ghost-btn ${active === "nl" ? "border-gold text-gold" : ""}`} onClick={() => patch({ translation: "nl" })}>
            Nederlands
          </button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <select className="rounded-card border border-line bg-surface px-3 py-3" value={surah} onChange={(e) => { setSurah(Number(e.target.value)); setAyah(1); }}>
            {meta.data?.surahs.map((s) => (
              <option key={s.n} value={s.n}>
                {surahLabel(s.name)}
              </option>
            ))}
          </select>
          <input inputMode="numeric" className="rounded-card border border-line bg-surface px-3 py-3" value={ayah} onChange={(e) => setAyah(Number(e.target.value.replace(/[^\d]/g, "")) || 1)} />
        </div>
        <article className="mushaf-day rounded-card p-4">
          <p className="quran-text text-2xl">
            {text} <span className="ayah-mark">{toArabicDigits(safe)}</span>
          </p>
        </article>
        <article className="card p-4 leading-relaxed" dir="ltr">
          {meaning || "…"}
        </article>
        <div className="flex gap-2">
          <button type="button" className="ghost-btn" onClick={() => toggle({ kind: "ayah", s: surah, a: safe })}>
            <Heart size={16} /> {has({ kind: "ayah", s: surah, a: safe }) ? "في المفضلة" : "حفظ الآية"}
          </button>
          <Link to="/mushaf/$surah" params={{ surah: String(surah) }} search={{ ayah: safe }} className="ghost-btn">
            فتح في المصحف
          </Link>
        </div>
      </Screen>
    </main>
  );
}
