import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Screen, TopBar } from "@/components/bits";
import { useDownloads } from "@/lib/downloads";
import { idbDeletePrefix, idbUsageBytes } from "@/lib/idb";
import { prepareOffline } from "@/lib/quran";
import { RECITERS, reciterName } from "@/lib/reciters";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const app = useApp();
  const clearReciter = useDownloads((s) => s.clearReciter);
  const [prep, setPrep] = useState("");
  const [usage, setUsage] = useState("");

  useEffect(() => {
    void idbUsageBytes().then((bytes) => {
      setUsage(bytes ? `${(bytes / (1024 * 1024)).toFixed(1)} م.ب تقريبًا من مساحة الموقع على الجهاز` : "سيظهر الحجم بعد حفظ المحتوى");
    });
  }, [prep, app.audioSaved]);

  const reminder = (
    key: "read" | "morning" | "evening" | "resume",
    label: string,
  ) => (
    <label className="card flex items-center gap-3 p-3" key={key}>
      <input
        type="checkbox"
        checked={app.reminders[key].enabled}
        onChange={async (e) => {
          if (e.target.checked && typeof Notification !== "undefined" && Notification.permission === "default") {
            await Notification.requestPermission();
          }
          app.patch({
            reminders: { ...app.reminders, [key]: { ...app.reminders[key], enabled: e.target.checked } },
          });
        }}
      />
      <span className="flex-1 text-sm">{label}</span>
      <input
        type="time"
        value={app.reminders[key].time}
        onChange={(e) =>
          app.patch({ reminders: { ...app.reminders, [key]: { ...app.reminders[key], time: e.target.value } } })
        }
        className="rounded-full border border-line bg-bg px-2 py-1"
      />
    </label>
  );

  return (
    <main>
      <TopBar title="الإعدادات" backTo="/more" />
      <Screen className="space-y-3 pb-8">
        <section className="card space-y-3 p-4">
          <h2 className="font-bold text-gold">العرض</h2>
          <div className="flex gap-2">
            <button type="button" className={`ghost-btn ${app.appearance === "night" ? "border-gold text-gold" : ""}`} onClick={() => app.patch({ appearance: "night" })}>
              ليلي زمردي
            </button>
            <button type="button" className={`ghost-btn ${app.appearance === "day" ? "border-gold text-gold" : ""}`} onClick={() => app.patch({ appearance: "day" })}>
              نهاري
            </button>
          </div>
          <div className="flex gap-2">
            <button type="button" className={`ghost-btn ${app.mushafTheme === "day" ? "border-gold text-gold" : ""}`} onClick={() => app.patch({ mushafTheme: "day" })}>
              مصحف كريمي
            </button>
            <button type="button" className={`ghost-btn ${app.mushafTheme === "night" ? "border-gold text-gold" : ""}`} onClick={() => app.patch({ mushafTheme: "night" })}>
              مصحف ليلي
            </button>
          </div>
          <label className="block text-sm">
            حجم خط المصحف
            <input
              type="range"
              min={0.85}
              max={1.7}
              step={0.05}
              value={app.fontScale}
              onChange={(e) => app.patch({ fontScale: Number(e.target.value) })}
              className="mt-2 w-full accent-gold"
            />
          </label>
          <label className="block text-sm">
            عرض الترجمة داخل المصحف
            <select
              className="mt-1 w-full rounded-card border border-line bg-bg px-3 py-3"
              value={app.translation}
              onChange={(e) => app.patch({ translation: e.target.value as "off" | "en" | "nl" })}
            >
              <option value="off">النص العربي فقط</option>
              <option value="en">ترجمة المعاني الإنجليزية</option>
              <option value="nl">ترجمة المعاني الهولندية</option>
            </select>
          </label>
          <p className="text-xs text-muted">واجهة التطبيق عربية واتجاهها من اليمين. لغة الترجمة تخص معاني الآيات فقط.</p>
        </section>

        <section className="card space-y-3 p-4">
          <h2 className="font-bold text-gold">القارئ والتفسير</h2>
          <label className="block text-sm">
            القارئ الافتراضي
            <select className="mt-1 w-full rounded-card border border-line bg-bg px-3 py-3" value={app.reciter} onChange={(e) => app.patch({ reciter: e.target.value })}>
              {RECITERS.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>
          <p className="text-sm text-muted">التفسير الافتراضي: التفسير الميسر، مجمع الملك فهد. وهو التفسير المضمّن ولا يتبدل من الشبكة.</p>
        </section>

        <section className="space-y-2">
          <h2 className="font-bold text-gold">التنبيهات</h2>
          <p className="text-xs leading-relaxed text-muted">
            التنبيه يعمل داخل التطبيق ما دام مفتوحًا، ويمكن للمتصفح إظهار إشعار إن سمحت بذلك. لا يوجد خادم يرسل التنبيهات. منبّه النظام المضمون والتطبيق مغلق تمامًا يحتاج تطبيق أندرويد أصليًا.
          </p>
          {reminder("read", "تذكير بقراءة القرآن")}
          {reminder("morning", "أذكار الصباح")}
          {reminder("evening", "أذكار المساء")}
          {reminder("resume", "متابعة القراءة")}
        </section>

        <section className="card space-y-3 p-4">
          <h2 className="font-bold text-gold">الملفات والمساحة</h2>
          <p className="text-sm text-muted">{usage}</p>
          <p className="text-sm text-muted">
            النص والتفسير والترجمات حوالي ٧ ميغابايت. التلاوة غير مضمّنة؛ كل قارئ بعد التنزيل حوالي ٣٠٠–٤٠٠ ميغابايت.
          </p>
          <button
            type="button"
            className="gold-btn w-full"
            onClick={() => {
              setPrep("جارٍ حفظ النصوص…");
              void prepareOffline((done, total) => setPrep(`حُفظ ${done} من ${total}`))
                .then(() => setPrep("النصوص جاهزة دون إنترنت على هذا الجهاز."))
                .catch(() => setPrep("تعذر إكمال الحفظ. حاول مجددًا وأنت متصل."));
            }}
          >
            حفظ كل النصوص للجهاز
          </button>
          {prep ? <p className="text-sm">{prep}</p> : null}
          {RECITERS.map((item) => (
            <button key={item.id} type="button" className="ghost-btn w-full" onClick={() => void clearReciter(item.id)}>
              حذف صوت {reciterName(item.id)}
            </button>
          ))}
          <button
            type="button"
            className="ghost-btn w-full"
            onClick={() => {
              void idbDeletePrefix("text", "/data/").then(() => {
                setPrep("مُسحت نسخ النصوص المؤقتة. ستُجلب من جديد عند الفتح المتصل.");
              });
              if ("caches" in window) void caches.keys().then((keys) => Promise.all(keys.map((key) => caches.delete(key))));
            }}
          >
            حذف الملفات النصية المؤقتة
          </button>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={app.searchHistoryOn} onChange={(e) => app.patch({ searchHistoryOn: e.target.checked })} />
            حفظ سجل البحث على الجهاز
          </label>
          <button type="button" className="ghost-btn w-full" onClick={() => app.clearSearch()}>
            مسح سجل البحث
          </button>
        </section>

        <section className="card space-y-2 p-4 text-sm leading-relaxed">
          <h2 className="font-bold text-gold">عن التطبيق</h2>
          <p>نور القرآن الكريم — Noor Al Quran</p>
          <p>المصحف: حفص عن عاصم، ٦٢٣٦ آية، ١١٤ سورة، ٦٠٤ صفحات، ٣٠ جزءًا.</p>
          <p>لا إعلانات، ولا حساب، ولا إرسال لبياناتك إلى خادم. المفضلة وآخر موضع والتلاوات المحفوظة تبقى في متصفحك.</p>
          <h3 className="pt-2 font-bold">الخصوصية</h3>
          <p>
            تحديد القبلة يستخدم موقع الجهاز فقط إن سمحت، ويُحفظ محليًا. تشغيل التلاوة أو تنزيلها يتصل بشبكة Islamic Network لنقل الملف الصوتي وحده. لا تُجمع قائمة استخدامك.
          </p>
          <h3 className="pt-2 font-bold">ما يعمل دون إنترنت</h3>
          <p>
            بعد أول فتح ناجح أو بعد زر الحفظ: المصحف، البحث، التفسير الميسر، الترجمتان، الأذكار، المفضلة، آخر موضع، وحساب القبلة من موقع محفوظ. التلاوة تعمل دون إنترنت فقط للسور التي نزّلتها.
          </p>
          <h3 className="pt-2 font-bold">مساعدة</h3>
          <p>من الرئيسية اختر المصحف أو تابع آخر قراءة. من الاستماع نزّل السورة قبل السفر. إن اضطربت القبلة فعاير البوصلة بعيدًا عن المعدن.</p>
        </section>
      </Screen>
    </main>
  );
}
