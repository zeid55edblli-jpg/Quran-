import { createFileRoute, Link } from "@tanstack/react-router";
import { Screen, TopBar } from "@/components/bits";
import { CATEGORIES } from "@/lib/adhkar";
import { toArabicDigits } from "@/lib/quran";

export const Route = createFileRoute("/_app/adhkar/")({
  component: AdhkarPage,
});

function AdhkarPage() {
  return (
    <main>
      <TopBar title="الأدعية والأذكار" backTo="/more" />
      <Screen className="space-y-3">
        <p className="text-sm leading-relaxed text-muted">
          الآيات تُعرض من المصحف المضمّن. الأذكار النبوية من الصحيحين والسنن مع مصدر كل ذكر. لا يُنسب حديث إلى غير مصدره المذكور.
        </p>
        <ul className="space-y-2">
          {CATEGORIES.map((category) => (
            <li key={category.id}>
              <Link to="/adhkar/$id" params={{ id: category.id }} className="card block p-4">
                <p className="font-bold">{category.title}</p>
                <p className="mt-1 text-sm text-muted">{category.blurb}</p>
                <p className="mt-2 text-xs text-gold">{toArabicDigits(category.items.length)} أذكار</p>
              </Link>
            </li>
          ))}
        </ul>
      </Screen>
    </main>
  );
}
