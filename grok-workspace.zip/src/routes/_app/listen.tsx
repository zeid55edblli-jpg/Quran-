import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Download, Pause, Play, Square, Trash2 } from "lucide-react";
import { useState } from "react";
import { Screen, TopBar } from "@/components/bits";
import { useDownloads } from "@/lib/downloads";
import { usePlayer, setPlaybackRate } from "@/lib/player";
import { loadMeta, surahLabel, toArabicDigits } from "@/lib/quran";
import { estimateBytes, formatBytes, RECITERS, reciterName } from "@/lib/reciters";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/listen")({
  component: ListenPage,
});

function ListenPage() {
  const meta = useQuery({ queryKey: ["meta"], queryFn: loadMeta });
  const reciter = useApp((s) => s.reciter);
  const rate = useApp((s) => s.rate);
  const repeat = useApp((s) => s.repeat);
  const saved = useApp((s) => s.audioSaved);
  const patch = useApp((s) => s.patch);
  const toggleFav = useApp((s) => s.toggleFav);
  const hasFav = useApp((s) => s.hasFav);
  const player = usePlayer();
  const job = useDownloads((s) => s.job);
  const startSurah = useDownloads((s) => s.startSurah);
  const startAll = useDownloads((s) => s.startAll);
  const pause = useDownloads((s) => s.pause);
  const resume = useDownloads((s) => s.resume);
  const clearReciter = useDownloads((s) => s.clearReciter);
  const [confirmAll, setConfirmAll] = useState(false);
  const [filter, setFilter] = useState("");

  const surahs = (meta.data?.surahs ?? []).filter((s) => {
    const needle = filter.trim();
    if (!needle) return true;
    return surahLabel(s.name).includes(needle) || String(s.n) === needle;
  });

  const allEstimate = estimateBytes(6236);

  return (
    <main>
      <TopBar title="الاستماع" backTo="/" />
      <Screen className="space-y-3">
        <section className="card p-4">
          <p className="text-sm text-muted">القارئ</p>
          <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
            {RECITERS.map((item) => (
              <button
                key={item.id}
                type="button"
                className={`shrink-0 rounded-full px-3 py-2 text-sm ${reciter === item.id ? "bg-gold font-bold text-cream-ink" : "bg-surface-2 text-fg"}`}
                onClick={() => patch({ reciter: item.id })}
              >
                {item.name}
              </button>
            ))}
          </div>
          <p className="mt-3 text-xs leading-relaxed text-muted">
            التلاوة صوت حقيقي من شبكة Islamic Network بجودة ٦٤. لا تُخزَّن داخل التطبيق ابتداءً بسبب الحجم وحقوق التسجيلات.
            بعد التنزيل تُحفظ على هذا الجهاز وتُشغَّل دون إنترنت. التقدير التقريبي للقارئ كاملًا: {formatBytes(allEstimate)}.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" className="gold-btn" onClick={() => setConfirmAll(true)}>
              <Download size={16} /> تنزيل كل السور
            </button>
            <button type="button" className="ghost-btn" onClick={() => void clearReciter(reciter)}>
              <Trash2 size={16} /> حذف تلاوات هذا القارئ
            </button>
          </div>
          {job ? (
            <div className="mt-3">
              <p className="text-sm">
                تنزيل {job.label}: {toArabicDigits(job.done)} / {toArabicDigits(job.total)} · {formatBytes(job.bytes)}
              </p>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-surface-2">
                <div className="h-full bg-gold" style={{ width: `${job.total ? (job.done / job.total) * 100 : 0}%` }} />
              </div>
              {job.error ? <p className="mt-1 text-sm text-danger">{job.error}</p> : null}
              <div className="mt-2 flex gap-2">
                {job.paused ? (
                  <button type="button" className="ghost-btn" onClick={resume}>
                    استكمال
                  </button>
                ) : (
                  <button type="button" className="ghost-btn" onClick={pause}>
                    إيقاف التنزيل
                  </button>
                )}
              </div>
            </div>
          ) : null}
        </section>

        <section className="card p-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <p className="text-sm text-muted">{player.surah ? reciterName(reciter) : "لم يبدأ التشغيل"}</p>
              <p className="font-bold">
                {player.surah && meta.data
                  ? `${surahLabel(meta.data.surahs[player.surah - 1]?.name ?? "")} · الآية ${toArabicDigits(player.ayah)}`
                  : "اختر سورة"}
              </p>
            </div>
            <button type="button" className="gold-btn h-12 w-12 px-0" aria-label="تشغيل أو إيقاف" onClick={() => player.toggle()} disabled={!player.surah}>
              {player.playing ? <Pause /> : <Play />}
            </button>
          </div>
          <input
            className="mt-3 w-full accent-gold"
            type="range"
            min={0}
            max={1000}
            value={player.duration ? Math.round((player.current / player.duration) * 1000) : 0}
            onChange={(e) => player.seek(Number(e.target.value) / 1000)}
            aria-label="موضع الاستماع"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" className="ghost-btn" onClick={() => void player.prev()}>
              السابقة
            </button>
            <button type="button" className="ghost-btn" onClick={() => void player.next()}>
              التالية
            </button>
            {([0.75, 1, 1.25, 1.5, 2] as const).map((value) => (
              <button
                key={value}
                type="button"
                className={`ghost-btn ${rate === value ? "border-gold text-gold" : ""}`}
                onClick={() => {
                  patch({ rate: value });
                  setPlaybackRate(value);
                }}
              >
                {value}×
              </button>
            ))}
          </div>
          <div className="mt-2 flex gap-2">
            {(
              [
                ["off", "دون تكرار"],
                ["ayah", "تكرار الآية"],
                ["surah", "تكرار السورة"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                className={`ghost-btn ${repeat === id ? "border-gold text-gold" : ""}`}
                onClick={() => patch({ repeat: id })}
              >
                {label}
              </button>
            ))}
          </div>
          {player.error ? <p className="mt-2 text-sm text-danger">{player.error}</p> : null}
          <p className="mt-2 text-xs text-muted">يستمر الصوت عند الانتقال بين الصفحات. أزرار قفل الشاشة تعتمد على دعم المتصفح.</p>
        </section>

        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="ابحث عن سورة"
          className="w-full rounded-card border border-line bg-surface px-4 py-3 outline-none"
        />

        <ul className="space-y-2">
          {surahs.map((s) => {
            const count = saved[`${reciter}:${s.n}`] ?? 0;
            const active = player.surah === s.n;
            return (
              <li key={s.n} className="card flex items-center gap-2 px-3 py-3">
                <button
                  type="button"
                  className="icon-btn"
                  aria-label={active && player.playing ? "إيقاف" : "تشغيل"}
                  onClick={() => {
                    if (active && player.playing) player.toggle();
                    else void player.play(s.n, active ? player.ayah : 1);
                  }}
                >
                  {active && player.playing ? <Square size={18} /> : <Play size={18} />}
                </button>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">
                    {toArabicDigits(s.n)}. {surahLabel(s.name)}
                  </p>
                  <p className="text-xs text-muted">
                    {count >= s.ayahs ? "محفوظة دون إنترنت" : count > 0 ? `تنزيل جزئي ${toArabicDigits(count)}/${toArabicDigits(s.ayahs)}` : `غير محفوظة · حوالي ${formatBytes(estimateBytes(s.ayahs))}`}
                  </p>
                </div>
                <button type="button" className="ghost-btn px-3" onClick={() => startSurah(reciter, s.n)} aria-label="تنزيل السورة">
                  <Download size={16} />
                </button>
                <button
                  type="button"
                  className={`text-xs ${hasFav({ kind: "audio", s: s.n, reciter }) ? "text-gold" : "text-muted"}`}
                  onClick={() => toggleFav({ kind: "audio", s: s.n, reciter })}
                >
                  مفضلة
                </button>
              </li>
            );
          })}
        </ul>
      </Screen>

      {confirmAll ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-4" role="dialog" aria-modal="true">
          <div className="card w-full max-w-lg space-y-3 p-4">
            <h2 className="text-lg font-bold">تنزيل كل سور {reciterName(reciter)}؟</h2>
            <p className="text-sm leading-relaxed text-muted">
              الحجم التقريبي {formatBytes(allEstimate)}. يُحفظ على هذا الجهاز ويمكن إيقافه واستكماله. لا يبدأ التنزيل إلا بعد موافقتك، ويحتاج اتصالًا.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                className="gold-btn flex-1"
                onClick={() => {
                  setConfirmAll(false);
                  startAll(reciter);
                }}
              >
                ابدأ التنزيل
              </button>
              <button type="button" className="ghost-btn flex-1" onClick={() => setConfirmAll(false)}>
                إلغاء
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}
