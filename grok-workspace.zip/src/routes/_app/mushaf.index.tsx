import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Screen, TopBar } from "@/components/bits";
import { loadMeta, normalizeArabic, surahLabel, toArabicDigits } from "@/lib/quran";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/mushaf/")({
  component: MushafIndex,
});

function MushafIndex() {
  const meta = useQuery({ queryKey: ["meta"], queryFn: loadMeta });
  const [tab, setTab] = useState<"surah" | "juz" | "page">("surah");
  const [q, setQ] = useState("");
  const [page, setPage] = useState("1");
  const fav = useApp((s) => s.favorites);
  const toggle = useApp((s) => s.toggleFav);
  const has = useApp((s) => s.hasFav);

  const surahs = useMemo(() => {
    const list = meta.data?.surahs ?? [];
    const needle = normalizeArabic(q);
    if (!needle) return list;
    return list.filter((s) => normalizeArabic(s.name).includes(needle) || s.en.toLowerCase().includes(q.toLowerCase()) || String(s.n) === q.trim());
  }, [meta.data, q]);

  const jumpPage = () => {
    const n = Number(page);
    if (!meta.data || n < 1 || n > 604) return null;
    return meta.data.pages[n - 1];
  };

  return (
    <main>
      <TopBar title="المصحف الشريف" backTo="/" />
      <Screen>
        <div className="mb-3 flex rounded-full bg-surface p-1">
          {(
            [
              ["surah", "السور"],
              ["juz", "الأجزاء"],
              ["page", "الصفحات"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              className={`min-h-11 flex-1 rounded-full text-sm font-semibold ${tab === id ? "bg-gold text-cream-ink" : "text-muted"}`}
              onClick={() => setTab(id)}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === "surah" ? (
          <>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث باسم السورة"
              className="mb-3 w-full rounded-card border border-line bg-surface px-4 py-3 outline-none"
            />
            <ul className="space-y-2">
              {surahs.map((s) => (
                <li key={s.n} className="card flex items-center gap-3 px-3 py-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full border border-gold text-sm font-bold text-gold">
                    {toArabicDigits(s.n)}
                  </span>
                  <Link to="/mushaf/$surah" params={{ surah: String(s.n) }} search={{ ayah: 1 }} className="min-w-0 flex-1">
                    <p className="truncate font-bold">{surahLabel(s.name)}</p>
                    <p className="text-xs text-muted">
                      {s.type === "makki" ? "مكية" : "مدنية"} · {toArabicDigits(s.ayahs)} آية · {s.en}
                    </p>
                  </Link>
                  <button
                    type="button"
                    className={`text-sm ${has({ kind: "surah", s: s.n }) ? "text-gold" : "text-muted"}`}
                    onClick={() => toggle({ kind: "surah", s: s.n })}
                  >
                    {has({ kind: "surah", s: s.n }) ? "محفوظة" : "حفظ"}
                  </button>
                </li>
              ))}
            </ul>
          </>
        ) : null}

        {tab === "juz" && meta.data ? (
          <ul className="grid grid-cols-2 gap-2">
            {meta.data.juz.map(([s, a], index) => (
              <li key={index}>
                <Link
                  to="/mushaf/$surah"
                  params={{ surah: String(s) }}
                  search={{ ayah: a }}
                  className="card block px-3 py-4"
                >
                  <p className="font-bold text-gold">الجزء {toArabicDigits(index + 1)}</p>
                  <p className="text-sm text-muted">
                    {surahLabel(meta.data.surahs[s - 1]?.name ?? "")} · {toArabicDigits(a)}
                  </p>
                </Link>
              </li>
            ))}
          </ul>
        ) : null}

        {tab === "page" && meta.data ? (
          <form
            className="card space-y-3 p-4"
            onSubmit={(e) => {
              e.preventDefault();
              const target = jumpPage();
              if (!target) return;
              const anchor = document.getElementById("page-go");
              anchor?.setAttribute("data-s", String(target[0]));
              anchor?.setAttribute("data-a", String(target[1]));
              anchor?.click();
            }}
          >
            <p className="text-sm text-muted">المصحف ٦٠٤ صفحات. أدخل رقم الصفحة للانتقال إلى أول آية فيها.</p>
            <input
              inputMode="numeric"
              value={page}
              onChange={(e) => setPage(e.target.value.replace(/[^\d]/g, "").slice(0, 3))}
              className="w-full rounded-card border border-line bg-bg px-4 py-3 text-center text-2xl outline-none"
            />
            {(() => {
              const target = jumpPage();
              if (!target) return <p className="text-sm text-danger">أدخل رقمًا من ١ إلى ٦٠٤</p>;
              return (
                <Link
                  id="page-go"
                  to="/mushaf/$surah"
                  params={{ surah: String(target[0]) }}
                  search={{ ayah: target[1] }}
                  className="gold-btn w-full"
                >
                  انتقل إلى الصفحة {toArabicDigits(page)}
                </Link>
              );
            })()}
            <p className="text-sm text-muted">الأحزاب: كل جزء حزبان، وكل حزب أربعة أرباع. رقم الربع يظهر داخل صفحة القراءة.</p>
          </form>
        ) : null}
        {fav.length === 0 ? null : null}
      </Screen>
    </main>
  );
}
