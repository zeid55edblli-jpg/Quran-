import { Link, createFileRoute } from "@tanstack/react-router";
import { BookMarked, Compass, Heart, Languages, Search, Settings, Star } from "lucide-react";
import { Screen, TopBar } from "@/components/bits";

export const Route = createFileRoute("/_app/more")({
  component: MorePage,
});

const LINKS = [
  { to: "/tafsir", label: "التفسير", icon: BookMarked },
  { to: "/translate", label: "ترجمة المعاني", icon: Languages },
  { to: "/adhkar", label: "الأدعية والأذكار", icon: Heart },
  { to: "/qibla", label: "اتجاه القبلة", icon: Compass },
  { to: "/search", label: "البحث", icon: Search },
  { to: "/favorites", label: "المفضلة", icon: Star },
  { to: "/settings", label: "الإعدادات", icon: Settings },
] as const;

function MorePage() {
  return (
    <main>
      <TopBar title="المزيد" />
      <Screen className="space-y-2">
        {LINKS.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.to} to={item.to} className="card flex items-center gap-3 px-4 py-4">
              <Icon className="text-gold" />
              <span className="font-semibold">{item.label}</span>
            </Link>
          );
        })}
      </Screen>
    </main>
  );
}
