import { useQuery } from "@tanstack/react-query";
import { Link, createFileRoute } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Empty, Screen, TopBar } from "@/components/bits";
import { findDhikr } from "@/lib/adhkar";
import { loadMeta, surahLabel, toArabicDigits } from "@/lib/quran";
import { reciterName } from "@/lib/reciters";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/favorites")({
  component: FavoritesPage,
});

function FavoritesPage() {
  const favs = useApp((s) => s.favorites);
  const toggle = useApp((s) => s.toggleFav);
  const meta = useQuery({ queryKey: ["meta"], queryFn: loadMeta });
  const name = (s: number) => (meta.data ? surahLabel(meta.data.surahs[s - 1]?.name ?? "") : `سورة ${s}`);

  const groups = [
    { title: "سور", items: favs.filter((f) => f.kind === "surah") },
    { title: "آيات", items: favs.filter((f) => f.kind === "ayah") },
    { title: "تلاوات", items: favs.filter((f) => f.kind === "audio") },
    { title: "أذكار", items: favs.filter((f) => f.kind === "dhikr") },
    { title: "تفسيرات", items: favs.filter((f) => f.kind === "tafsir") },
  ];

  return (
    <main>
      <TopBar title="المفضلة" backTo="/more" />
      <Screen className="space-y-4">
        {favs.length === 0 ? <Empty text="لا توجد عناصر محفوظة بعد. الحفظ يبقى على هذا الجهاز دون حساب." /> : null}
        {groups.map((group) =>
          group.items.length ? (
            <section key={group.title}>
              <h2 className="mb-2 font-bold text-gold">{group.title}</h2>
              <ul className="space-y-2">
                {group.items.map((item, index) => {
                  if (item.kind === "surah") {
                    return (
                      <Row key={index} onRemove={() => toggle(item)}>
                        <Link to="/mushaf/$surah" params={{ surah: String(item.s) }} search={{ ayah: 1 }}>
                          {name(item.s)}
                        </Link>
                      </Row>
                    );
                  }
                  if (item.kind === "ayah" || item.kind === "tafsir") {
                    const href = item.kind === "tafsir" ? null : true;
                    return (
                      <Row key={index} onRemove={() => toggle(item)}>
                        {href ? (
                          <Link to="/mushaf/$surah" params={{ surah: String(item.s) }} search={{ ayah: item.a }}>
                            {name(item.s)} · {toArabicDigits(item.a)}
                          </Link>
                        ) : (
                          <Link to="/tafsir" search={{ s: item.s, a: item.a }}>
                            {name(item.s)} · {toArabicDigits(item.a)}
                          </Link>
                        )}
                      </Row>
                    );
                  }
                  if (item.kind === "audio") {
                    return (
                      <Row key={index} onRemove={() => toggle(item)}>
                        <Link to="/listen">
                          {name(item.s)} · {reciterName(item.reciter)}
                        </Link>
                      </Row>
                    );
                  }
                  const dhikr = findDhikr(item.id);
                  return (
                    <Row key={index} onRemove={() => toggle(item)}>
                      <Link to="/adhkar/$id" params={{ id: dhikr?.category.id ?? "morning" }}>
                        {dhikr?.item.title || dhikr?.item.text?.slice(0, 42) || item.id}
                      </Link>
                    </Row>
                  );
                })}
              </ul>
            </section>
          ) : null,
        )}
      </Screen>
    </main>
  );
}

function Row({ children, onRemove }: { children: ReactNode; onRemove: () => void }) {
  return (
    <li className="card flex items-center justify-between gap-3 px-3 py-3">
      <div className="min-w-0 flex-1 font-semibold">{children}</div>
      <button type="button" className="text-sm text-muted" onClick={onRemove}>
        إزالة
      </button>
    </li>
  );
}
