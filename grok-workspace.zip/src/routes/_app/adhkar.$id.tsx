import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Screen, TopBar } from "@/components/bits";
import { CATEGORIES, type Dhikr } from "@/lib/adhkar";
import { loadSurah, toArabicDigits } from "@/lib/quran";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/adhkar/$id")({
  component: DhikrList,
});

function DhikrList() {
  const { id } = Route.useParams();
  const category = CATEGORIES.find((item) => item.id === id);
  if (!category) {
    return (
      <main>
        <TopBar title="الأذكار" backTo="/adhkar" />
        <Screen>هذا القسم غير موجود.</Screen>
      </main>
    );
  }
  return (
    <main>
      <TopBar title={category.title} backTo="/adhkar" />
      <Screen className="space-y-3">
        {category.items.map((item) => (
          <DhikrCard key={item.id} item={item} />
        ))}
      </Screen>
    </main>
  );
}

function DhikrCard({ item }: { item: Dhikr }) {
  const count = useApp((s) => s.dhikrCounts[item.id] ?? 0);
  const setDhikr = useApp((s) => s.setDhikr);
  const toggle = useApp((s) => s.toggleFav);
  const has = useApp((s) => s.hasFav);
  const done = count >= item.repeat;
  return (
    <article className="card p-4">
      {item.title ? <p className="mb-1 text-sm text-gold">{item.title}</p> : null}
      {item.ref ? <QuranDhikr s={item.ref.s} a={item.ref.a} a2={item.ref.a2} /> : <p className="quran-text text-2xl leading-loose">{item.text}</p>}
      <p className="mt-2 text-xs leading-relaxed text-muted">{item.source}</p>
      <button
        type="button"
        className={`mt-3 flex h-28 w-full flex-col items-center justify-center rounded-card border ${done ? "border-gold bg-gold text-cream-ink" : "border-gold/50 bg-surface-2"}`}
        onClick={() => setDhikr(item.id, Math.min(item.repeat, count + 1))}
      >
        <span className="text-3xl font-bold">
          {toArabicDigits(count)} / {toArabicDigits(item.repeat)}
        </span>
        <span className="text-sm">{done ? "تم" : "اضغط للعد"}</span>
      </button>
      <div className="mt-2 flex gap-2">
        <button type="button" className="ghost-btn" onClick={() => setDhikr(item.id, 0)}>
          إعادة العداد
        </button>
        <button type="button" className="ghost-btn" onClick={() => toggle({ kind: "dhikr", id: item.id })}>
          {has({ kind: "dhikr", id: item.id }) ? "في المفضلة" : "حفظ"}
        </button>
      </div>
    </article>
  );
}

function QuranDhikr({ s, a, a2 }: { s: number; a: number; a2?: number }) {
  const q = useQuery({ queryKey: ["surah", s], queryFn: () => loadSurah(s) });
  const [text, setText] = useState("");
  useEffect(() => {
    if (!q.data) return;
    const parts = q.data.ayahs.filter((ayah) => ayah.a >= a && ayah.a <= (a2 ?? a)).map((ayah) => ayah.t);
    setText(parts.join(" "));
  }, [q.data, a, a2]);
  return <p className="quran-text text-2xl leading-loose">{text || "…"}</p>;
}
