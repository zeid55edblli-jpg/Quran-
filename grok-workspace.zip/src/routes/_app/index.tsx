import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import {
  BookMarked,
  BookOpen,
  Compass,
  Headphones,
  Heart,
  Languages,
  Search,
  Settings,
} from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { dayOfYear, loadMeta, surahLabel, toArabicDigits } from "@/lib/quran";
import { reciterName } from "@/lib/reciters";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/")({
  component: HomePage,
});

const TILES = [
  { to: "/mushaf", label: "المصحف الشريف", icon: BookOpen },
  { to: "/listen", label: "الاستماع", icon: Headphones },
  { to: "/tafsir", label: "التفسير", icon: BookMarked },
  { to: "/translate", label: "الترجمة", icon: Languages },
  { to: "/adhkar", label: "الأدعية والأذكار", icon: Heart },
  { to: "/qibla", label: "اتجاه القبلة", icon: Compass },
  { to: "/search", label: "البحث", icon: Search },
  { to: "/favorites", label: "المفضلة", icon: Heart },
] as const;

function HomePage() {
  const meta = useQuery({ queryKey: ["meta"], queryFn: loadMeta });
  const last = useApp((s) => s.lastRead);
  const listen = useApp((s) => s.lastListen);
  const daily = meta.data ? meta.data.daily[dayOfYear() % meta.data.daily.length] : null;
  const lastSurah = last && meta.data ? meta.data.surahs[last.s - 1] : null;

  return (
    <main className="rise">
      <header className="flex items-center gap-3 px-4 pt-5">
        <img src="/art/emblem.jpg" alt="" className="h-12 w-12 rounded-full border border-gold object-cover" />
        <div className="min-w-0 flex-1">
          <p className="text-xs text-gold">Noor Al Quran</p>
          <h1 className="truncate text-xl font-bold">نور القرآن الكريم</h1>
        </div>
        <Link to="/settings" className="icon-btn" aria-label="الإعدادات">
          <Settings />
        </Link>
      </header>

      <section className="relative mx-4 mt-4 overflow-hidden rounded-card">
        <img src="/art/splash.jpg" alt="" className="h-44 w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/75 to-transparent" />
        <p className="absolute inset-x-0 bottom-0 p-4 text-lg font-semibold">القرآن الكريم، رفيقك في كل مكان</p>
      </section>

      <div className="space-y-3 px-4 py-4">
        {meta.isError ? (
          <p className="card px-4 py-3 text-sm text-danger">تعذر فتح قاعدة المصحف على هذا الجهاز.</p>
        ) : null}

        <section className="card p-4">
          <p className="text-sm text-muted">آخر موضع قراءة</p>
          {last && lastSurah ? (
            <>
              <p className="mt-1 text-lg font-bold">{surahLabel(lastSurah.name)}</p>
              <p className="text-sm text-muted">
                الآية {toArabicDigits(last.a)} · الجزء {toArabicDigits(last.j)} · الصفحة {toArabicDigits(last.p)}
              </p>
              <Link
                to="/mushaf/$surah"
                params={{ surah: String(last.s) }}
                search={{ ayah: last.a }}
                className="gold-btn mt-3 w-full"
              >
                متابعة القراءة
              </Link>
            </>
          ) : (
            <>
              <p className="mt-1 font-semibold">لم تبدأ القراءة بعد</p>
              <Link to="/mushaf" className="gold-btn mt-3 w-full">
                افتح المصحف
              </Link>
            </>
          )}
        </section>

        {listen ? (
          <Link to="/listen" className="card block p-4">
            <p className="text-sm text-muted">آخر استماع</p>
            <p className="mt-1 font-semibold">
              {meta.data ? surahLabel(meta.data.surahs[listen.s - 1]?.name ?? "") : "السورة"} · الآية{" "}
              {toArabicDigits(listen.a)}
            </p>
            <p className="text-sm text-gold">{reciterName(listen.reciter)}</p>
          </Link>
        ) : null}

        <section className="card p-4">
          <div className="flex items-center justify-between gap-3">
            <p className="text-sm text-gold">الآية اليومية</p>
            {daily ? (
              <Link to="/mushaf/$surah" params={{ surah: String(daily.s) }} search={{ ayah: daily.a }} className="text-xs text-muted">
                {meta.data ? surahLabel(meta.data.surahs[daily.s - 1]?.name ?? "") : ""} · {toArabicDigits(daily.a)}
              </Link>
            ) : null}
          </div>
          <p className="quran-text mt-2 text-2xl">{daily?.t ?? "…"}</p>
          <p className="mt-2 text-xs text-muted">من نص المصحف المضمّن، وتتبدل حسب اليوم. ليست نصًا مولدًا.</p>
        </section>

        <div className="grid grid-cols-2 gap-3">
          {TILES.map((tile) => {
            const Icon = tile.icon;
            return (
              <Link key={tile.to} to={tile.to} className="card flex min-h-24 flex-col justify-between p-4">
                <Icon className="text-gold" />
                <span className="mt-3 font-semibold">{tile.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </main>
  );
}
