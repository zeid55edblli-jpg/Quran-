import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Screen, TopBar } from "@/components/bits";
import { CITIES, normalizeDeg, qiblaBearing } from "@/lib/qibla";
import { toArabicDigits } from "@/lib/quran";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/qibla")({
  component: QiblaPage,
});

type Heading = { deg: number | null; absolute: boolean };

function readHeading(event: DeviceOrientationEvent & { webkitCompassHeading?: number }): Heading {
  if (typeof event.webkitCompassHeading === "number" && !Number.isNaN(event.webkitCompassHeading)) {
    return { deg: event.webkitCompassHeading, absolute: true };
  }
  if (typeof event.alpha === "number" && event.absolute) {
    return { deg: normalizeDeg(360 - event.alpha), absolute: true };
  }
  if (typeof event.alpha === "number") return { deg: normalizeDeg(360 - event.alpha), absolute: false };
  return { deg: null, absolute: false };
}

function QiblaPage() {
  const place = useApp((s) => s.place);
  const patch = useApp((s) => s.patch);
  const [heading, setHeading] = useState<Heading>({ deg: null, absolute: false });
  const [sensorNote, setSensorNote] = useState("لم تُفعَّل البوصلة بعد.");
  const [lat, setLat] = useState(place ? String(place.lat) : "");
  const [lon, setLon] = useState(place ? String(place.lon) : "");
  const [manualError, setManualError] = useState("");

  useEffect(() => {
    const onOrient = (event: Event) => {
      const next = readHeading(event as DeviceOrientationEvent & { webkitCompassHeading?: number });
      if (next.deg == null) return;
      setHeading(next);
      setSensorNote(next.absolute ? "الاتجاه من مستشعر الجهاز." : "المستشعر نسبي وقد يحتاج معايرة، فلا يُعتمد عليه وحده.");
    };
    window.addEventListener("deviceorientationabsolute", onOrient);
    window.addEventListener("deviceorientation", onOrient);
    return () => {
      window.removeEventListener("deviceorientationabsolute", onOrient);
      window.removeEventListener("deviceorientation", onOrient);
    };
  }, []);

  const askSensor = async () => {
    const ctor = DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
    try {
      if (typeof ctor.requestPermission === "function") {
        const result = await ctor.requestPermission();
        if (result !== "granted") {
          setSensorNote("رُفض الإذن. يمكن معرفة الزاوية من الشمال دون تحريك البوصلة.");
          return;
        }
      }
      setSensorNote("حرّك الهاتف بشكل رقم ٨ بعيدًا عن المغناطيس إن اضطربت الإبرة.");
    } catch {
      setSensorNote("تعذر طلب إذن البوصلة في هذا المتصفح.");
    }
  };

  const askLocation = () => {
    if (!navigator.geolocation) {
      setSensorNote("الموقع غير متاح. اختر مدينة أو أدخل الإحداثيات.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        patch({
          place: {
            lat: pos.coords.latitude,
            lon: pos.coords.longitude,
            label: "موقعي",
          },
        });
        setLat(pos.coords.latitude.toFixed(4));
        setLon(pos.coords.longitude.toFixed(4));
      },
      () => setSensorNote("تعذر تحديد الموقع. اختر المدينة يدويًا، والحساب بعدها محلي."),
      { enableHighAccuracy: true, timeout: 8000 },
    );
  };

  const bearing = place ? normalizeDeg(qiblaBearing(place.lat, place.lon)) : null;
  const delta = bearing != null && heading.deg != null ? normalizeDeg(bearing - heading.deg) : null;
  const aligned = delta != null && (delta < 8 || delta > 352);

  return (
    <main>
      <TopBar title="اتجاه القبلة" backTo="/more" />
      <Screen className="space-y-3">
        <section className="card flex flex-col items-center px-4 py-6">
          <div className="relative h-64 w-64">
            <div
              className="absolute inset-0 rounded-full border-2 border-gold"
              style={{ transform: heading.deg != null ? `rotate(${-heading.deg}deg)` : undefined }}
            >
              <span className="absolute left-1/2 top-2 -translate-x-1/2 text-sm font-bold text-gold">ش</span>
              <span className="absolute bottom-2 left-1/2 -translate-x-1/2 text-xs text-muted">ج</span>
              <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-muted">غ</span>
              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-muted">ق</span>
              {bearing != null ? (
                <span
                  className="absolute left-1/2 top-1/2 h-28 w-1 origin-bottom bg-gold"
                  style={{ transform: `translate(-50%, -100%) rotate(${bearing}deg)` }}
                />
              ) : null}
            </div>
            <div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold" />
          </div>
          <p className="mt-4 text-center text-lg font-bold">
            {bearing == null ? "حدد موقعك أولًا" : aligned ? "أنت باتجاه القبلة" : `القبلة على ${toArabicDigits(Math.round(bearing))}° من الشمال`}
          </p>
          <p className="mt-1 text-center text-sm text-muted">{sensorNote}</p>
          {!heading.absolute && heading.deg != null ? (
            <p className="mt-2 text-center text-sm text-danger">
              قد يوجد تداخل أو قراءة غير مطلقة. ابتعد عن المغناطيس وأعد المعايرة برسم رقم ٨ بالهاتف.
            </p>
          ) : null}
        </section>

        <div className="flex gap-2">
          <button type="button" className="gold-btn flex-1" onClick={askLocation}>
            تحديد موقعي
          </button>
          <button type="button" className="ghost-btn flex-1" onClick={() => void askSensor()}>
            تفعيل البوصلة
          </button>
        </div>

        <label className="block text-sm">
          المدينة
          <select
            className="mt-1 w-full rounded-card border border-line bg-surface px-3 py-3"
            value={place?.label ?? ""}
            onChange={(e) => {
              const city = CITIES.find((item) => item.name === e.target.value);
              if (!city) return;
              patch({ place: { lat: city.lat, lon: city.lon, label: city.name } });
              setLat(String(city.lat));
              setLon(String(city.lon));
            }}
          >
            <option value="">اختر مدينة</option>
            {CITIES.map((city) => (
              <option key={city.name} value={city.name}>
                {city.name}
              </option>
            ))}
          </select>
        </label>

        <form
          className="card space-y-2 p-4"
          onSubmit={(e) => {
            e.preventDefault();
            const la = Number(lat);
            const lo = Number(lon);
            if (!Number.isFinite(la) || !Number.isFinite(lo) || Math.abs(la) > 90 || Math.abs(lo) > 180) {
              setManualError("أدخل خط عرض بين -٩٠ و٩٠ وخط طول بين -١٨٠ و١٨٠.");
              return;
            }
            setManualError("");
            patch({ place: { lat: la, lon: lo, label: "إحداثيات يدوية" } });
          }}
        >
          <p className="text-sm text-muted">أو أدخل الإحداثيات. الحساب محلي ولا يحتاج إنترنت بعد حفظ الموقع.</p>
          <div className="grid grid-cols-2 gap-2">
            <input value={lat} onChange={(e) => setLat(e.target.value)} placeholder="خط العرض" className="rounded-card border border-line bg-bg px-3 py-3" dir="ltr" />
            <input value={lon} onChange={(e) => setLon(e.target.value)} placeholder="خط الطول" className="rounded-card border border-line bg-bg px-3 py-3" dir="ltr" />
          </div>
          {manualError ? <p className="text-sm text-danger">{manualError}</p> : null}
          <button type="submit" className="ghost-btn w-full">
            احسب من الإحداثيات
          </button>
        </form>
        {place ? (
          <p className="text-center text-xs text-muted">
            الموقع المستخدم: {place.label} ({place.lat.toFixed(3)}, {place.lon.toFixed(3)})
          </p>
        ) : null}
      </Screen>
    </main>
  );
}
