import { useQuery } from "@tanstack/react-query";
import { Link, createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Empty, Screen, TopBar } from "@/components/bits";
import {
  loadMeta,
  loadNorm,
  loadTafsir,
  loadTranslation,
  normalizeArabic,
  parseDigits,
  surahLabel,
  toArabicDigits,
} from "@/lib/quran";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/search")({
  component: SearchPage,
});

type Hit = { s: number; a: number; preview: string; where: string };

function SearchPage() {
  const meta = useQuery({ queryKey: ["meta"], queryFn: loadMeta });
  const [q, setQ] = useState("");
  const [scope, setScope] = useState<"quran" | "en" | "nl" | "tafsir">("quran");
  const [hits, setHits] = useState<Hit[]>([]);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");
  const history = useApp((s) => s.searchHistory);
  const pushSearch = useApp((s) => s.pushSearch);

  const run = async (query: string) => {
    const raw = query.trim();
    if (!raw || !meta.data) return;
    pushSearch(raw);
    setBusy(true);
    setNote("");
    const found: Hit[] = [];
    const numeric = parseDigits(raw).match(/^(\d+)\s*[:/]\s*(\d+)$/);
    if (numeric) {
      const s = Number(numeric[1]);
      const a = Number(numeric[2]);
      const info = meta.data.surahs[s - 1];
      if (info && a >= 1 && a <= info.ayahs) found.push({ s, a, preview: "انتقال برقم الآية", where: "رقم" });
    }
    try {
      if (scope === "quran") {
        const norm = await loadNorm();
        const needle = normalizeArabic(raw);
        if (needle) {
          norm.forEach((rows, si) => {
            rows.forEach((row, ai) => {
              if (found.length < 40 && row.includes(needle)) {
                found.push({ s: si + 1, a: ai + 1, preview: row, where: "المصحف" });
              }
            });
          });
        }
      } else if (scope === "tafsir") {
        const needle = normalizeArabic(raw);
        for (let s = 1; s <= 114 && found.length < 30; s++) {
          const rows = await loadTafsir(s);
          rows.forEach((row, ai) => {
            if (found.length < 30 && normalizeArabic(row).includes(needle)) {
              found.push({ s, a: ai + 1, preview: row.slice(0, 160), where: "التفسير" });
            }
          });
        }
      } else {
        const rows = await loadTranslation(scope);
        const needle = raw.toLowerCase();
        rows.forEach((surahRows, si) => {
          surahRows.forEach((row, ai) => {
            if (found.length < 40 && row.toLowerCase().includes(needle)) {
              found.push({ s: si + 1, a: ai + 1, preview: row.slice(0, 180), where: scope === "en" ? "الإنجليزية" : "الهولندية" });
            }
          });
        });
      }
      setHits(found);
      if (!found.length) setNote("لا توجد نتائج في المحتوى المحفوظ على الجهاز.");
    } catch {
      setNote("تعذر البحث. افتح الإعدادات واحفظ النصوص أثناء الاتصال ثم أعد المحاولة دون إنترنت.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main>
      <TopBar title="البحث" backTo="/more" />
      <Screen className="space-y-3">
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            void run(q);
          }}
        >
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="كلمة، أو ٢:٢٥٥"
            className="min-w-0 flex-1 rounded-card border border-line bg-surface px-4 py-3 outline-none"
          />
          <button type="submit" className="gold-btn px-4" disabled={busy}>
            {busy ? "…" : "ابحث"}
          </button>
        </form>
        <div className="flex flex-wrap gap-2">
          {(
            [
              ["quran", "المصحف"],
              ["tafsir", "التفسير"],
              ["en", "الإنجليزية"],
              ["nl", "الهولندية"],
            ] as const
          ).map(([id, label]) => (
            <button key={id} type="button" className={`ghost-btn ${scope === id ? "border-gold text-gold" : ""}`} onClick={() => setScope(id)}>
              {label}
            </button>
          ))}
        </div>
        <p className="text-xs text-muted">البحث محلي داخل النصوص المخزنة، ولا يُرسل إلى خادم.</p>
        {history.length ? (
          <div className="flex flex-wrap gap-2">
            {history.map((item) => (
              <button key={item} type="button" className="ghost-btn" onClick={() => { setQ(item); void run(item); }}>
                {item}
              </button>
            ))}
          </div>
        ) : null}
        {note ? <Empty text={note} /> : null}
        <ul className="space-y-2">
          {hits.map((hit) => (
            <li key={`${hit.where}-${hit.s}-${hit.a}-${hit.preview.slice(0, 12)}`}>
              <Link to="/mushaf/$surah" params={{ surah: String(hit.s) }} search={{ ayah: hit.a }} className="card block p-3">
                <p className="text-sm text-gold">
                  {meta.data ? surahLabel(meta.data.surahs[hit.s - 1]?.name ?? "") : ""} · {toArabicDigits(hit.a)} · {hit.where}
                </p>
                <p className="mt-1 line-clamp-3 text-sm leading-relaxed">{hit.preview}</p>
              </Link>
            </li>
          ))}
        </ul>
      </Screen>
    </main>
  );
}
