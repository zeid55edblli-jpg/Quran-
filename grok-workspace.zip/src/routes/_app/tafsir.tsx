import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Copy, Heart, Share2 } from "lucide-react";
import { useState } from "react";
import { Screen, TopBar } from "@/components/bits";
import { loadMeta, loadSurah, loadTafsir, surahLabel, toArabicDigits } from "@/lib/quran";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/_app/tafsir")({
  validateSearch: (search: Record<string, unknown>) => ({
    s: Number(search.s) || 1,
    a: Number(search.a) || 1,
  }),
  component: TafsirPage,
});

function TafsirPage() {
  const search = Route.useSearch();
  const [surah, setSurah] = useState(search.s);
  const [ayah, setAyah] = useState(search.a);
  const meta = useQuery({ queryKey: ["meta"], queryFn: loadMeta });
  const q = useQuery({ queryKey: ["surah", surah], queryFn: () => loadSurah(surah) });
  const tf = useQuery({ queryKey: ["tf", surah], queryFn: () => loadTafsir(surah) });
  const scale = useApp((s) => s.fontScale);
  const patch = useApp((s) => s.patch);
  const toggle = useApp((s) => s.toggleFav);
  const has = useApp((s) => s.hasFav);
  const info = meta.data?.surahs[surah - 1];
  const safeAyah = info ? Math.min(Math.max(1, ayah), info.ayahs) : ayah;
  const text = q.data?.ayahs[safeAyah - 1]?.t ?? "";
  const explanation = tf.data?.[safeAyah - 1] ?? "";
  const bundle = `${text}\n\n${explanation}\n\n${meta.data?.tafsirSource ?? ""}`;

  return (
    <main>
      <TopBar title="التفسير" backTo="/more" />
      <Screen className="space-y-3">
        <p className="text-xs leading-relaxed text-muted">{meta.data?.tafsirSource}</p>
        <div className="grid grid-cols-2 gap-2">
          <label className="text-sm">
            السورة
            <select
              className="mt-1 w-full rounded-card border border-line bg-surface px-3 py-3"
              value={surah}
              onChange={(e) => {
                setSurah(Number(e.target.value));
                setAyah(1);
              }}
            >
              {meta.data?.surahs.map((s) => (
                <option key={s.n} value={s.n}>
                  {toArabicDigits(s.n)} {surahLabel(s.name)}
                </option>
              ))}
            </select>
          </label>
          <label className="text-sm">
            الآية
            <input
              inputMode="numeric"
              className="mt-1 w-full rounded-card border border-line bg-surface px-3 py-3"
              value={ayah}
              onChange={(e) => setAyah(Number(e.target.value.replace(/[^\d]/g, "")) || 1)}
            />
          </label>
        </div>
        <div className="flex gap-2">
          <button type="button" className="ghost-btn" onClick={() => patch({ fontScale: Math.max(0.85, scale - 0.1) })}>
            خط أصغر
          </button>
          <button type="button" className="ghost-btn" onClick={() => patch({ fontScale: Math.min(1.7, scale + 0.1) })}>
            خط أكبر
          </button>
          <Link to="/mushaf/$surah" params={{ surah: String(surah) }} search={{ ayah: safeAyah }} className="ghost-btn">
            في المصحف
          </Link>
        </div>
        <article className="mushaf-day rounded-card p-4">
          <p className="quran-text" style={{ fontSize: `${1.45 * scale}rem` }}>
            {text || "…"} <span className="ayah-mark">{toArabicDigits(safeAyah)}</span>
          </p>
        </article>
        <article className="card p-4 leading-relaxed" style={{ fontSize: `${scale}rem` }}>
          {tf.isError ? "تعذر فتح التفسير. احفظ المحتوى للجهاز من الإعدادات أثناء الاتصال." : explanation || "…"}
        </article>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="ghost-btn" onClick={() => void navigator.clipboard.writeText(bundle).then(() => useApp.getState().showToast("تم النسخ"))}>
            <Copy size={16} /> نسخ
          </button>
          <button
            type="button"
            className="ghost-btn"
            onClick={() => {
              if (navigator.share) void navigator.share({ title: "التفسير الميسر", text: bundle }).catch(() => undefined);
              else void navigator.clipboard.writeText(bundle);
            }}
          >
            <Share2 size={16} /> مشاركة
          </button>
          <button type="button" className="ghost-btn" onClick={() => toggle({ kind: "tafsir", s: surah, a: safeAyah })}>
            <Heart size={16} /> {has({ kind: "tafsir", s: surah, a: safeAyah }) ? "محفوظ" : "حفظ التفسير"}
          </button>
        </div>
      </Screen>
    </main>
  );
}
