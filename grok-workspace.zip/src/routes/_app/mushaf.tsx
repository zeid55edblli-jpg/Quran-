import { Outlet, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/mushaf")({
  component: () => <Outlet />,
});
