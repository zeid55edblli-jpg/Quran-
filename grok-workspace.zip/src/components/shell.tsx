import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { BookOpen, Headphones, Home, Menu, Pause, Play } from "lucide-react";
import { useEffect, useState } from "react";
import { bindAudio, usePlayer } from "@/lib/player";
import { loadMeta, surahLabel, toArabicDigits } from "@/lib/quran";
import { reciterName } from "@/lib/reciters";
import { useApp } from "@/lib/store";

const NAV = [
  { to: "/", label: "الرئيسية", icon: Home, exact: true },
  { to: "/mushaf", label: "المصحف", icon: BookOpen, exact: false },
  { to: "/listen", label: "الاستماع", icon: Headphones, exact: false },
  { to: "/more", label: "المزيد", icon: Menu, exact: false },
] as const;

function Splash() {
  const [hydrated, setHydrated] = useState(false);
  const seen = useApp((s) => s.seenSplash);
  const mark = useApp((s) => s.markSplash);

  useEffect(() => {
    const finish = () => setHydrated(true);
    const unsub = useApp.persist.onFinishHydration(finish);
    if (useApp.persist.hasHydrated()) finish();
    return unsub;
  }, []);

  if (!hydrated || seen) return null;

  return (
    <div className="fixed inset-0 z-50 mx-auto flex max-w-lg flex-col bg-bg">
      <img src="/art/splash.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-b from-bg/30 via-bg/55 to-bg" />
      <div className="relative flex flex-1 flex-col items-center justify-end px-6 pb-10 text-center">
        <img src="/art/emblem.jpg" alt="" className="mb-4 h-24 w-24 rounded-full border border-gold object-cover shadow-lg" />
        <p className="text-sm tracking-widest text-gold">NOOR AL QURAN</p>
        <h1 className="mt-1 text-4xl font-bold text-gold">نور القرآن الكريم</h1>
        <p className="mt-3 text-xl text-fg">نور لقلبك</p>
        <p className="mt-1 text-muted">رفيقك في كل مكان</p>
        <button type="button" className="gold-btn mt-8 w-full" onClick={mark}>
          ابدأ الآن
        </button>
        <button type="button" className="mt-3 text-sm text-muted" onClick={mark}>
          تخطي
        </button>
      </div>
    </div>
  );
}

function MiniPlayer() {
  const surah = usePlayer((s) => s.surah);
  const ayah = usePlayer((s) => s.ayah);
  const playing = usePlayer((s) => s.playing);
  const toggle = usePlayer((s) => s.toggle);
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { data } = useMetaSafe();
  if (!surah || path.startsWith("/listen")) return null;
  const name = data ? surahLabel(data.surahs[surah - 1]?.name ?? "") : "التلاوة";
  return (
    <div className="fixed inset-x-0 bottom-16 z-30 mx-auto w-full max-w-lg px-3">
      <div className="card flex items-center gap-3 px-3 py-2">
        <button type="button" className="icon-btn" onClick={toggle} aria-label={playing ? "إيقاف" : "تشغيل"}>
          {playing ? <Pause /> : <Play />}
        </button>
        <Link to="/listen" className="min-w-0 flex-1">
          <p className="truncate font-semibold">{name}</p>
          <p className="truncate text-xs text-muted">الآية {toArabicDigits(ayah)}</p>
        </Link>
      </div>
    </div>
  );
}

function useMetaSafe() {
  const [data, setData] = useState<Awaited<ReturnType<typeof loadMeta>> | null>(null);
  useEffect(() => {
    void loadMeta().then(setData).catch(() => undefined);
  }, []);
  return { data };
}

function ReminderEngine() {
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const time = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      const stamp = `${now.toDateString()} ${time}`;
      const state = useApp.getState();
      if (state.reminderStamp === stamp) return;
      const labels = {
        read: "تذكير بقراءة القرآن",
        morning: "تذكير بأذكار الصباح",
        evening: "تذكير بأذكار المساء",
        resume: "تذكير بمتابعة القراءة",
      } as const;
      const hit = (Object.keys(labels) as (keyof typeof labels)[]).find(
        (key) => state.reminders[key].enabled && state.reminders[key].time === time,
      );
      if (!hit) return;
      state.patch({ reminderStamp: stamp });
      state.showToast(labels[hit]);
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        new Notification("نور القرآن الكريم", { body: labels[hit] });
      }
    };
    const id = window.setInterval(tick, 15000);
    return () => window.clearInterval(id);
  }, []);
  return null;
}

export function AppShell() {
  const appearance = useApp((s) => s.appearance);
  const toast = useApp((s) => s.toast);
  const path = useRouterState({ select: (s) => s.location.pathname });
  const queryClient = useQueryClient();
  const playing = usePlayer((s) => s.playing);
  const surah = usePlayer((s) => s.surah);

  useEffect(() => bindAudio(), []);
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);
  useEffect(() => {
    void queryClient.prefetchQuery({ queryKey: ["meta"], queryFn: loadMeta });
  }, [queryClient]);

  const pad = surah && !path.startsWith("/listen") ? "pb-36" : "pb-20";

  return (
    <div className={`app-bg min-h-dvh text-fg ${appearance === "day" ? "theme-day" : ""}`}>
      <div className={`mx-auto flex min-h-dvh w-full max-w-lg flex-col ${pad}`}>
        <Outlet />
      </div>
      <MiniPlayer />
      <nav className="fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-lg border-t border-line bg-bg/95 backdrop-blur">
        <div className="flex">
          {NAV.map((item) => {
            const active = item.exact ? path === item.to : path === item.to || path.startsWith(`${item.to}/`);
            const Icon = item.icon;
            return (
              <Link key={item.to} to={item.to} className={`nav-item ${active ? "active" : ""}`}>
                <Icon size={20} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
      {toast ? (
        <div className="fixed inset-x-0 bottom-24 z-50 mx-auto w-fit max-w-lg rounded-full bg-surface-2 px-4 py-2 text-sm text-fg shadow">
          {toast}
        </div>
      ) : null}
      <Splash />
      <ReminderEngine />
      <span className="sr-only">{playing ? reciterName(useApp.getState().reciter) : ""}</span>
    </div>
  );
}
