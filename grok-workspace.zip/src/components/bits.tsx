import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { ChevronRight } from "lucide-react";

export function TopBar({
  title,
  backTo,
  action,
}: {
  title: string;
  backTo?: string;
  action?: ReactNode;
}) {
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-bg/90 px-3 py-2 backdrop-blur">
      {backTo ? (
        <button
          type="button"
          className="icon-btn"
          aria-label="رجوع"
          onClick={() => {
            if (window.history.length > 1) navigate({ to: backTo });
            else navigate({ to: backTo });
          }}
        >
          <ChevronRight />
        </button>
      ) : (
        <span className="w-11" />
      )}
      <h1 className="flex-1 truncate text-center text-lg font-bold text-gold">{title}</h1>
      <div className="flex w-11 justify-end">{action}</div>
    </header>
  );
}

export function Screen({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`px-4 py-4 ${className}`}>{children}</div>;
}

export function Empty({ text }: { text: string }) {
  return <p className="card px-4 py-8 text-center text-sm text-muted">{text}</p>;
}

export function usePath() {
  return useRouterState({ select: (state) => state.location.pathname });
}

export function TextLink({
  to,
  children,
  className = "",
}: {
  to: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Link to={to} className={className}>
      {children}
    </Link>
  );
}
