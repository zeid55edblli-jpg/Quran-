//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-7c4BUjkK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/_app"],
		preloads: [
			"/assets/index-CLp4g9fP.js",
			"/assets/createLucideIcon-ByvwkBVD.js",
			"/assets/preload-helper-BCmF_b5R.js",
			"/assets/link-BLaZt-Sr.js",
			"/assets/useMatch-Bs9pylPz.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CLp4g9fP.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app/route.tsx",
		children: [
			"/_app/adhkar",
			"/_app/favorites",
			"/_app/listen",
			"/_app/more",
			"/_app/mushaf",
			"/_app/qibla",
			"/_app/search",
			"/_app/settings",
			"/_app/tafsir",
			"/_app/translate",
			"/_app/"
		],
		preloads: [
			"/assets/route-C5QRXtI7.js",
			"/assets/headphones-CM9AEgua.js",
			"/assets/pause-zSI6utKu.js",
			"/assets/player-D6aZ9N-I.js",
			"/assets/query-CmqvdIUB.js",
			"/assets/quran-DID8xbiO.js",
			"/assets/store-DYxANvnp.js",
			"/assets/reciters-Bk-V7C9_.js"
		]
	},
	"/_app/adhkar": {
		filePath: "/workspace/src/routes/_app/adhkar.tsx",
		children: ["/_app/adhkar/$id"],
		preloads: [
			"/assets/adhkar-CZyxKGVM.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/adhkar--fOKD1VN.js"
		]
	},
	"/_app/favorites": {
		filePath: "/workspace/src/routes/_app/favorites.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-CvDQ70QQ.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/useQuery-BNE419Qg.js",
			"/assets/adhkar--fOKD1VN.js"
		]
	},
	"/_app/listen": {
		filePath: "/workspace/src/routes/_app/listen.tsx",
		children: void 0,
		preloads: [
			"/assets/listen-C4qbeh8y.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/useQuery-BNE419Qg.js",
			"/assets/downloads-Bop7Ca4K.js"
		]
	},
	"/_app/more": {
		filePath: "/workspace/src/routes/_app/more.tsx",
		children: void 0,
		preloads: [
			"/assets/more-BJA_Z2qF.js",
			"/assets/settings-ZEMEsVwN.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/heart-BZe8UhkQ.js"
		]
	},
	"/_app/mushaf": {
		filePath: "/workspace/src/routes/_app/mushaf.tsx",
		children: ["/_app/mushaf/$surah"],
		preloads: [
			"/assets/mushaf-DcJi444E.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/useQuery-BNE419Qg.js"
		]
	},
	"/_app/qibla": {
		filePath: "/workspace/src/routes/_app/qibla.tsx",
		children: void 0,
		preloads: ["/assets/qibla-O4x49v6E.js", "/assets/bits-BY-rHlZK.js"]
	},
	"/_app/search": {
		filePath: "/workspace/src/routes/_app/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-D09S7OEi.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/useQuery-BNE419Qg.js"
		]
	},
	"/_app/settings": {
		filePath: "/workspace/src/routes/_app/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CCvidMQt.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/downloads-Bop7Ca4K.js"
		]
	},
	"/_app/tafsir": {
		filePath: "/workspace/src/routes/_app/tafsir.tsx",
		children: void 0,
		preloads: [
			"/assets/tafsir-QyfOYotq.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/share-2-BFEJzhLt.js",
			"/assets/heart-BZe8UhkQ.js",
			"/assets/useQuery-BNE419Qg.js"
		]
	},
	"/_app/translate": {
		filePath: "/workspace/src/routes/_app/translate.tsx",
		children: void 0,
		preloads: [
			"/assets/translate-DT0Nc-M-.js",
			"/assets/bits-BY-rHlZK.js",
			"/assets/heart-BZe8UhkQ.js",
			"/assets/useQuery-BNE419Qg.js"
		]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_app-X4p3NNSd.js",
			"/assets/settings-ZEMEsVwN.js",
			"/assets/heart-BZe8UhkQ.js",
			"/assets/useQuery-BNE419Qg.js"
		]
	},
	"/_app/adhkar/$id": {
		filePath: "/workspace/src/routes/_app/adhkar.$id.tsx",
		children: void 0,
		preloads: ["/assets/adhkar._id-BKQlbeUJ.js", "/assets/useQuery-BNE419Qg.js"]
	},
	"/_app/mushaf/$surah": {
		filePath: "/workspace/src/routes/_app/mushaf.$surah.tsx",
		children: void 0,
		preloads: [
			"/assets/mushaf._surah-4-YYXb9d.js",
			"/assets/share-2-BFEJzhLt.js",
			"/assets/heart-BZe8UhkQ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
