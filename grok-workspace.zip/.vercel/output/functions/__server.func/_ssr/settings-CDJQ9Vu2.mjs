import { i as __toESM } from "../_runtime.mjs";
import { m as prepareOffline, o as idbUsageBytes, r as idbDeletePrefix } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { a as reciterName, t as RECITERS } from "./reciters-BvKEdjn7.mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
import { t as useDownloads } from "./downloads-B-ZClEDz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CDJQ9Vu2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const app = useApp();
	const clearReciter = useDownloads((s) => s.clearReciter);
	const [prep, setPrep] = (0, import_react.useState)("");
	const [usage, setUsage] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		idbUsageBytes().then((bytes) => {
			setUsage(bytes ? `${(bytes / 1048576).toFixed(1)} م.ب تقريبًا من مساحة الموقع على الجهاز` : "سيظهر الحجم بعد حفظ المحتوى");
		});
	}, [prep, app.audioSaved]);
	const reminder = (key, label) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "card flex items-center gap-3 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				checked: app.reminders[key].enabled,
				onChange: async (e) => {
					if (e.target.checked && typeof Notification !== "undefined" && Notification.permission === "default") await Notification.requestPermission();
					app.patch({ reminders: {
						...app.reminders,
						[key]: {
							...app.reminders[key],
							enabled: e.target.checked
						}
					} });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 text-sm",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "time",
				value: app.reminders[key].time,
				onChange: (e) => app.patch({ reminders: {
					...app.reminders,
					[key]: {
						...app.reminders[key],
						time: e.target.value
					}
				} }),
				className: "rounded-full border border-line bg-bg px-2 py-1"
			})
		]
	}, key);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "الإعدادات",
		backTo: "/more"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		className: "space-y-3 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold text-gold",
						children: "العرض"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `ghost-btn ${app.appearance === "night" ? "border-gold text-gold" : ""}`,
							onClick: () => app.patch({ appearance: "night" }),
							children: "ليلي زمردي"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `ghost-btn ${app.appearance === "day" ? "border-gold text-gold" : ""}`,
							onClick: () => app.patch({ appearance: "day" }),
							children: "نهاري"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `ghost-btn ${app.mushafTheme === "day" ? "border-gold text-gold" : ""}`,
							onClick: () => app.patch({ mushafTheme: "day" }),
							children: "مصحف كريمي"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `ghost-btn ${app.mushafTheme === "night" ? "border-gold text-gold" : ""}`,
							onClick: () => app.patch({ mushafTheme: "night" }),
							children: "مصحف ليلي"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: ["حجم خط المصحف", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: .85,
							max: 1.7,
							step: .05,
							value: app.fontScale,
							onChange: (e) => app.patch({ fontScale: Number(e.target.value) }),
							className: "mt-2 w-full accent-gold"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: ["عرض الترجمة داخل المصحف", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "mt-1 w-full rounded-card border border-line bg-bg px-3 py-3",
							value: app.translation,
							onChange: (e) => app.patch({ translation: e.target.value }),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "off",
									children: "النص العربي فقط"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "en",
									children: "ترجمة المعاني الإنجليزية"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "nl",
									children: "ترجمة المعاني الهولندية"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "واجهة التطبيق عربية واتجاهها من اليمين. لغة الترجمة تخص معاني الآيات فقط."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold text-gold",
						children: "القارئ والتفسير"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: ["القارئ الافتراضي", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "mt-1 w-full rounded-card border border-line bg-bg px-3 py-3",
							value: app.reciter,
							onChange: (e) => app.patch({ reciter: e.target.value }),
							children: RECITERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "التفسير الافتراضي: التفسير الميسر، مجمع الملك فهد. وهو التفسير المضمّن ولا يتبدل من الشبكة."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold text-gold",
						children: "التنبيهات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted",
						children: "التنبيه يعمل داخل التطبيق ما دام مفتوحًا، ويمكن للمتصفح إظهار إشعار إن سمحت بذلك. لا يوجد خادم يرسل التنبيهات. منبّه النظام المضمون والتطبيق مغلق تمامًا يحتاج تطبيق أندرويد أصليًا."
					}),
					reminder("read", "تذكير بقراءة القرآن"),
					reminder("morning", "أذكار الصباح"),
					reminder("evening", "أذكار المساء"),
					reminder("resume", "متابعة القراءة")
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold text-gold",
						children: "الملفات والمساحة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: usage
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "النص والتفسير والترجمات حوالي ٧ ميغابايت. التلاوة غير مضمّنة؛ كل قارئ بعد التنزيل حوالي ٣٠٠–٤٠٠ ميغابايت."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "gold-btn w-full",
						onClick: () => {
							setPrep("جارٍ حفظ النصوص…");
							prepareOffline((done, total) => setPrep(`حُفظ ${done} من ${total}`)).then(() => setPrep("النصوص جاهزة دون إنترنت على هذا الجهاز.")).catch(() => setPrep("تعذر إكمال الحفظ. حاول مجددًا وأنت متصل."));
						},
						children: "حفظ كل النصوص للجهاز"
					}),
					prep ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: prep
					}) : null,
					RECITERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ghost-btn w-full",
						onClick: () => void clearReciter(item.id),
						children: ["حذف صوت ", reciterName(item.id)]
					}, item.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ghost-btn w-full",
						onClick: () => {
							idbDeletePrefix("text", "/data/").then(() => {
								setPrep("مُسحت نسخ النصوص المؤقتة. ستُجلب من جديد عند الفتح المتصل.");
							});
							if ("caches" in window) caches.keys().then((keys) => Promise.all(keys.map((key) => caches.delete(key))));
						},
						children: "حذف الملفات النصية المؤقتة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: app.searchHistoryOn,
							onChange: (e) => app.patch({ searchHistoryOn: e.target.checked })
						}), "حفظ سجل البحث على الجهاز"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ghost-btn w-full",
						onClick: () => app.clearSearch(),
						children: "مسح سجل البحث"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card space-y-2 p-4 text-sm leading-relaxed",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold text-gold",
						children: "عن التطبيق"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "نور القرآن الكريم — Noor Al Quran" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "المصحف: حفص عن عاصم، ٦٢٣٦ آية، ١١٤ سورة، ٦٠٤ صفحات، ٣٠ جزءًا." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "لا إعلانات، ولا حساب، ولا إرسال لبياناتك إلى خادم. المفضلة وآخر موضع والتلاوات المحفوظة تبقى في متصفحك." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "pt-2 font-bold",
						children: "الخصوصية"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "تحديد القبلة يستخدم موقع الجهاز فقط إن سمحت، ويُحفظ محليًا. تشغيل التلاوة أو تنزيلها يتصل بشبكة Islamic Network لنقل الملف الصوتي وحده. لا تُجمع قائمة استخدامك." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "pt-2 font-bold",
						children: "ما يعمل دون إنترنت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "بعد أول فتح ناجح أو بعد زر الحفظ: المصحف، البحث، التفسير الميسر، الترجمتان، الأذكار، المفضلة، آخر موضع، وحساب القبلة من موقع محفوظ. التلاوة تعمل دون إنترنت فقط للسور التي نزّلتها." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "pt-2 font-bold",
						children: "مساعدة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "من الرئيسية اختر المصحف أو تابع آخر قراءة. من الاستماع نزّل السورة قبل السفر. إن اضطربت القبلة فعاير البوصلة بعيدًا عن المعدن." })
				]
			})
		]
	})] });
}
//#endregion
export { SettingsPage as component };
