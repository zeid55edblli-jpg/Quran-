import { i as __toESM } from "../_runtime.mjs";
import { d as loadTranslation, g as toArabicDigits, h as surahLabel, l as loadSurah, s as loadMeta } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as Bookmark, f as Minus, g as Heart, l as Plus, o as Share2, r as SunMoon, u as Play, y as Copy } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-Bl5MT34k.mjs";
import { r as usePlayer } from "./player-D4zMIWHV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mushaf._surah-Cep79G6g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function copyText(text) {
	await navigator.clipboard.writeText(text);
	useApp.getState().showToast("تم النسخ");
}
async function shareText(text) {
	if (navigator.share) try {
		await navigator.share({
			title: "نور القرآن الكريم",
			text
		});
		return;
	} catch {
		return;
	}
	await copyText(text);
}
function ReaderPage() {
	const { surah: surahParam } = Route.useParams();
	const { ayah: initialAyah } = Route.useSearch();
	const surah = Number(surahParam);
	const meta = useQuery({
		queryKey: ["meta"],
		queryFn: loadMeta
	});
	const data = useQuery({
		queryKey: ["surah", surah],
		queryFn: () => loadSurah(surah),
		enabled: surah >= 1 && surah <= 114
	});
	const translation = useApp((s) => s.translation);
	const trans = useQuery({
		queryKey: ["tr", translation],
		queryFn: () => loadTranslation(translation === "nl" ? "nl" : "en"),
		enabled: translation !== "off"
	});
	const theme = useApp((s) => s.mushafTheme);
	const scale = useApp((s) => s.fontScale);
	const patch = useApp((s) => s.patch);
	const setLastRead = useApp((s) => s.setLastRead);
	const toggleFav = useApp((s) => s.toggleFav);
	const hasFav = useApp((s) => s.hasFav);
	const play = usePlayer((s) => s.play);
	const [selected, setSelected] = (0, import_react.useState)(initialAyah);
	const scroller = (0, import_react.useRef)(null);
	const info = meta.data?.surahs[surah - 1];
	(0, import_react.useEffect)(() => {
		document.getElementById(`ayah-${initialAyah}`)?.scrollIntoView({ block: "center" });
	}, [initialAyah, data.data]);
	(0, import_react.useEffect)(() => {
		const root = scroller.current;
		if (!root || !info) return;
		const obs = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (!visible) return;
			const ayah = Number(visible.target.dataset.ayah);
			const page = Number(visible.target.dataset.page);
			const juz = Number(visible.target.dataset.juz);
			if (!ayah) return;
			setLastRead({
				s: surah,
				a: ayah,
				p: page,
				j: juz
			});
		}, {
			root,
			threshold: .6
		});
		root.querySelectorAll("[data-ayah]").forEach((node) => obs.observe(node));
		return () => obs.disconnect();
	}, [
		data.data,
		info,
		setLastRead,
		surah
	]);
	if (!info && meta.isSuccess) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "p-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "السورة غير موجودة." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/mushaf",
			className: "gold-btn mt-4",
			children: "العودة للسور"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-bg/92 px-3 py-2 backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/mushaf",
							className: "icon-btn",
							"aria-label": "السور",
							children: "السور"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate font-bold text-gold",
								children: info ? surahLabel(info.name) : "…"
							}), info ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									info.type === "makki" ? "مكية" : "مدنية",
									" · ",
									toArabicDigits(info.ayahs),
									" آية"
								]
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-btn",
							"aria-label": "وضع الصفحة",
							onClick: () => patch({ mushafTheme: theme === "day" ? "night" : "day" }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMoon, {})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex items-center justify-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-btn",
							"aria-label": "تصغير الخط",
							onClick: () => patch({ fontScale: Math.max(.85, scale - .1) }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: "حجم الخط"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-btn",
							"aria-label": "تكبير الخط",
							onClick: () => patch({ fontScale: Math.min(1.7, scale + .1) }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
						}),
						info ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `text-sm ${hasFav({
								kind: "surah",
								s: surah
							}) ? "text-gold" : "text-muted"}`,
							onClick: () => toggleFav({
								kind: "surah",
								s: surah
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
								className: "inline",
								size: 16
							}), " السورة"]
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: `mx-3 my-3 flex-1 overflow-auto rounded-card px-4 py-5 ${theme === "day" ? "mushaf-day" : "mushaf-night"}`,
				children: [
					info && surah !== 9 && surah !== 1 && meta.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "quran-text mb-4 text-center text-gold",
						style: { fontSize: `${1.7 * scale}rem` },
						children: meta.data.basmala
					}) : null,
					data.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center",
						children: "تعذر فتح السورة دون اتصال إن لم تُحفظ من قبل."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "quran-text",
						style: { fontSize: `${1.55 * scale}rem` },
						children: data.data?.ayahs.map((ayah) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AyahBlock, {
							ayah,
							surah,
							surahName: info ? surahLabel(info.name) : "",
							selected: selected === ayah.a,
							translation: translation === "off" ? "" : trans.data?.[surah - 1]?.[ayah.a - 1] ?? "",
							onSelect: () => setSelected(ayah.a),
							onPlay: () => void play(surah, ayah.a),
							faved: hasFav({
								kind: "ayah",
								s: surah,
								a: ayah.a
							}),
							onFav: () => toggleFav({
								kind: "ayah",
								s: surah,
								a: ayah.a
							})
						}, ayah.a))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 px-3 pb-3",
				children: [surah > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/mushaf/$surah",
					params: { surah: String(surah - 1) },
					search: { ayah: 1 },
					className: "ghost-btn flex-1",
					children: "السورة السابقة"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1" }), surah < 114 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/mushaf/$surah",
					params: { surah: String(surah + 1) },
					search: { ayah: 1 },
					className: "ghost-btn flex-1",
					children: "السورة التالية"
				}) : null]
			})
		]
	});
}
function AyahBlock({ ayah, surah, surahName, selected, translation, onSelect, onPlay, faved, onFav }) {
	const hizb = Math.ceil(ayah.h / 4);
	const quarter = (ayah.h - 1) % 4 + 1;
	const shareBody = `${ayah.t} ﴿${surahName}: ${ayah.a}﴾`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		id: `ayah-${ayah.a}`,
		"data-ayah": ayah.a,
		"data-page": ayah.p,
		"data-juz": ayah.j,
		className: "mb-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "w-full text-right",
				onClick: onSelect,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ayah.t }),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ayah-mark",
						children: toArabicDigits(ayah.a)
					})
				]
			}),
			translation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed opacity-80",
				style: { fontFamily: "Cairo, sans-serif" },
				children: translation
			}) : null,
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-2 text-sm",
				style: { fontFamily: "Cairo, sans-serif" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: onPlay,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 16 }), " استماع"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: () => void copyText(shareBody),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { size: 16 }), " نسخ"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: () => void shareText(shareBody),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { size: 16 }), " مشاركة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: onFav,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { size: 16 }),
							" ",
							faved ? "في المفضلة" : "مفضلة"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tafsir",
						search: {
							s: surah,
							a: ayah.a
						},
						className: "ghost-btn",
						children: "تفسير"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "self-center text-xs opacity-70",
						children: [
							"ص ",
							toArabicDigits(ayah.p),
							" · ج ",
							toArabicDigits(ayah.j),
							" · حزب ",
							toArabicDigits(hizb),
							" ربع ",
							toArabicDigits(quarter)
						]
					})
				]
			}) : null
		]
	});
}
//#endregion
export { ReaderPage as component };
