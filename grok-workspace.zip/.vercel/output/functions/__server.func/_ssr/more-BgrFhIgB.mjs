import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as Compass, c as Search, g as Heart, i as Star, m as Languages, s as Settings, w as BookMarked } from "../_libs/lucide-react.mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-BgrFhIgB.js
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		to: "/tafsir",
		label: "التفسير",
		icon: BookMarked
	},
	{
		to: "/translate",
		label: "ترجمة المعاني",
		icon: Languages
	},
	{
		to: "/adhkar",
		label: "الأدعية والأذكار",
		icon: Heart
	},
	{
		to: "/qibla",
		label: "اتجاه القبلة",
		icon: Compass
	},
	{
		to: "/search",
		label: "البحث",
		icon: Search
	},
	{
		to: "/favorites",
		label: "المفضلة",
		icon: Star
	},
	{
		to: "/settings",
		label: "الإعدادات",
		icon: Settings
	}
];
function MorePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { title: "المزيد" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		className: "space-y-2",
		children: LINKS.map((item) => {
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				className: "card flex items-center gap-3 px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: item.label
				})]
			}, item.to);
		})
	})] });
}
//#endregion
export { MorePage as component };
