import { i as __toESM } from "../_runtime.mjs";
import { d as loadTranslation, g as toArabicDigits, h as surahLabel, l as loadSurah, s as loadMeta } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as Heart } from "../_libs/lucide-react.mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/translate-ShOMamgx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TranslatePage() {
	const meta = useQuery({
		queryKey: ["meta"],
		queryFn: loadMeta
	});
	const [surah, setSurah] = (0, import_react.useState)(1);
	const [ayah, setAyah] = (0, import_react.useState)(1);
	const lang = useApp((s) => s.translation);
	const active = lang === "off" ? "en" : lang;
	const patch = useApp((s) => s.patch);
	const toggle = useApp((s) => s.toggleFav);
	const has = useApp((s) => s.hasFav);
	const q = useQuery({
		queryKey: ["surah", surah],
		queryFn: () => loadSurah(surah)
	});
	const tr = useQuery({
		queryKey: ["tr", active],
		queryFn: () => loadTranslation(active)
	});
	const info = meta.data?.surahs[surah - 1];
	const safe = info ? Math.min(info.ayahs, Math.max(1, ayah)) : 1;
	const text = q.data?.ayahs[safe - 1]?.t ?? "";
	const meaning = tr.data?.[surah - 1]?.[safe - 1] ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "ترجمة المعاني",
		backTo: "/more"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "card px-4 py-3 text-sm leading-relaxed text-muted",
				children: ["النص العربي هو القرآن. ما يظهر بالإنجليزية أو الهولندية ترجمة لمعانيه، وليس القرآن نفسه.", active === "en" ? ` المصدر: ${meta.data?.enSource ?? ""}` : ` المصدر: ${meta.data?.nlSource ?? ""}`]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `ghost-btn ${active === "en" ? "border-gold text-gold" : ""}`,
					onClick: () => patch({ translation: "en" }),
					children: "English"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `ghost-btn ${active === "nl" ? "border-gold text-gold" : ""}`,
					onClick: () => patch({ translation: "nl" }),
					children: "Nederlands"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "rounded-card border border-line bg-surface px-3 py-3",
					value: surah,
					onChange: (e) => {
						setSurah(Number(e.target.value));
						setAyah(1);
					},
					children: meta.data?.surahs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: s.n,
						children: surahLabel(s.name)
					}, s.n))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					inputMode: "numeric",
					className: "rounded-card border border-line bg-surface px-3 py-3",
					value: ayah,
					onChange: (e) => setAyah(Number(e.target.value.replace(/[^\d]/g, "")) || 1)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "mushaf-day rounded-card p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "quran-text text-2xl",
					children: [
						text,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ayah-mark",
							children: toArabicDigits(safe)
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "card p-4 leading-relaxed",
				dir: "ltr",
				children: meaning || "…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "ghost-btn",
					onClick: () => toggle({
						kind: "ayah",
						s: surah,
						a: safe
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { size: 16 }),
						" ",
						has({
							kind: "ayah",
							s: surah,
							a: safe
						}) ? "في المفضلة" : "حفظ الآية"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/mushaf/$surah",
					params: { surah: String(surah) },
					search: { ayah: safe },
					className: "ghost-btn",
					children: "فتح في المصحف"
				})]
			})
		]
	})] });
}
//#endregion
export { TranslatePage as component };
