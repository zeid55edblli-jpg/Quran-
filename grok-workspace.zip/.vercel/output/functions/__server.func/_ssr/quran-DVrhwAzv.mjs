//#region node_modules/.nitro/vite/services/ssr/assets/quran-DVrhwAzv.js
var DB_NAME = "noor-quran";
var DB_VERSION = 1;
var opening = null;
function openDb() {
	if (typeof indexedDB === "undefined") return Promise.reject(/* @__PURE__ */ new Error("التخزين المحلي غير متاح"));
	if (!opening) opening = new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, DB_VERSION);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains("text")) db.createObjectStore("text");
			if (!db.objectStoreNames.contains("audio")) db.createObjectStore("audio");
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => {
			opening = null;
			reject(req.error);
		};
	});
	return opening;
}
function txDone(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
		tx.onabort = () => reject(tx.error);
	});
}
async function idbGet(store, key) {
	try {
		const db = await openDb();
		return await new Promise((resolve, reject) => {
			const req = db.transaction(store, "readonly").objectStore(store).get(key);
			req.onsuccess = () => resolve(req.result);
			req.onerror = () => reject(req.error);
		});
	} catch {
		return;
	}
}
async function idbSet(store, key, value) {
	const tx = (await openDb()).transaction(store, "readwrite");
	tx.objectStore(store).put(value, key);
	await txDone(tx);
}
async function idbKeys(store, prefix = "") {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const req = db.transaction(store, "readonly").objectStore(store).getAllKeys();
		req.onsuccess = () => {
			resolve(req.result.map(String).filter((k) => k.startsWith(prefix)));
		};
		req.onerror = () => reject(req.error);
	});
}
async function idbDeletePrefix(store, prefix) {
	const keys = await idbKeys(store, prefix);
	if (!keys.length) return;
	const tx = (await openDb()).transaction(store, "readwrite");
	const os = tx.objectStore(store);
	for (const key of keys) os.delete(key);
	await txDone(tx);
}
async function idbUsageBytes() {
	if (typeof navigator !== "undefined" && navigator.storage?.estimate) {
		const { usage } = await navigator.storage.estimate();
		return usage ?? 0;
	}
	return 0;
}
var memory = /* @__PURE__ */ new Map();
var inflight = /* @__PURE__ */ new Map();
async function loadJson(url) {
	const hit = memory.get(url);
	if (hit) return hit;
	const pending = inflight.get(url);
	if (pending) return pending;
	const task = (async () => {
		try {
			const res = await fetch(url);
			if (!res.ok) throw new Error("تعذر التحميل");
			const data = await res.json();
			idbSet("text", url, data).catch(() => void 0);
			memory.set(url, data);
			return data;
		} catch (error) {
			const cached = await idbGet("text", url);
			if (cached) {
				memory.set(url, cached);
				return cached;
			}
			throw error;
		}
	})();
	inflight.set(url, task);
	try {
		return await task;
	} finally {
		inflight.delete(url);
	}
}
function loadMeta() {
	return loadJson("/data/meta.json");
}
function loadSurah(n) {
	return loadJson(`/data/q/${n}.json`);
}
function loadTafsir(n) {
	return loadJson(`/data/tf/${n}.json`);
}
function loadNorm() {
	return loadJson("/data/norm.json");
}
function loadTranslation(lang) {
	return loadJson(lang === "en" ? "/data/en.json" : "/data/nl.json");
}
function surahLabel(name) {
	return name.replace(/^سُورَةُ\s*/, "");
}
function toArabicDigits(value) {
	return String(value).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)] ?? d);
}
function globalOf(surah, ayah, surahs) {
	let g = ayah;
	for (let i = 0; i < surah - 1; i++) g += surahs[i]?.ayahs ?? 0;
	return g;
}
function normalizeArabic(input) {
	return input.replace(/[\u064B-\u065F\u0670\u06D6-\u06ED\u0640\uFEFF]/g, "").replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/[^\u0600-\u06FF0-9\s:]/g, " ").replace(/\s+/g, " ").trim();
}
function parseDigits(input) {
	const map = "٠١٢٣٤٥٦٧٨٩";
	return input.replace(/[٠-٩]/g, (d) => String(map.indexOf(d)));
}
function dayOfYear(date = /* @__PURE__ */ new Date()) {
	const start = Date.UTC(date.getUTCFullYear(), 0, 0);
	return Math.floor((date.getTime() - start) / 864e5);
}
var TEXT_URLS = [
	"/data/meta.json",
	"/data/norm.json",
	"/data/en.json",
	"/data/nl.json"
];
function allTextUrls() {
	const urls = [...TEXT_URLS];
	for (let i = 1; i <= 114; i++) urls.push(`/data/q/${i}.json`, `/data/tf/${i}.json`);
	return urls;
}
async function prepareOffline(onProgress) {
	const urls = allTextUrls();
	let done = 0;
	for (const url of urls) {
		await loadJson(url);
		done += 1;
		onProgress?.(done, urls.length);
	}
}
//#endregion
export { idbSet as a, loadNorm as c, loadTranslation as d, normalizeArabic as f, toArabicDigits as g, surahLabel as h, idbGet as i, loadSurah as l, prepareOffline as m, globalOf as n, idbUsageBytes as o, parseDigits as p, idbDeletePrefix as r, loadMeta as s, dayOfYear as t, loadTafsir as u };
