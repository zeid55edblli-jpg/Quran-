import { a as idbSet, n as globalOf, r as idbDeletePrefix, s as loadMeta } from "./quran-DVrhwAzv.mjs";
import { n as create } from "../_libs/zustand.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { n as audioUrl } from "./reciters-BvKEdjn7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/downloads-B-ZClEDz.js
var controllers = /* @__PURE__ */ new Map();
async function fetchAyah(reciter, globalAyah, signal) {
	const res = await fetch(audioUrl(reciter, globalAyah), { signal });
	if (!res.ok) throw new Error("تعذر تنزيل المقطع");
	const blob = await res.blob();
	await idbSet("audio", `${reciter}:${globalAyah}`, blob);
	return blob.size;
}
async function runRange(reciter, surah, fromAyah, signal, onAyah) {
	const meta = await loadMeta();
	const info = meta.surahs[surah - 1];
	if (!info) return;
	for (let ayah = fromAyah; ayah <= info.ayahs; ayah++) {
		if (signal.aborted) throw new DOMException("paused", "AbortError");
		const size = await fetchAyah(reciter, globalOf(surah, ayah, meta.surahs), signal);
		useApp.getState().setAudioSaved(`${reciter}:${surah}`, ayah);
		onAyah(size);
	}
}
var useDownloads = create((set, get) => ({
	job: null,
	startSurah: (reciter, surah) => {
		startJob(reciter, [{
			surah,
			from: (useApp.getState().audioSaved[`${reciter}:${surah}`] ?? 0) + 1
		}], `سورة ${surah}`, set, get);
	},
	startAll: (reciter) => {
		const saved = useApp.getState().audioSaved;
		const plan = [];
		for (let surah = 1; surah <= 114; surah++) plan.push({
			surah,
			from: (saved[`${reciter}:${surah}`] ?? 0) + 1
		});
		startJob(reciter, plan, "كل السور", set, get);
	},
	pause: () => {
		const job = get().job;
		if (!job) return;
		controllers.get(job.key)?.abort();
		set({ job: {
			...job,
			paused: true
		} });
	},
	resume: () => {
		const job = get().job;
		if (!job?.paused) return;
		const reciter = job.key.split(":")[0] ?? "";
		if (job.label === "كل السور") get().startAll(reciter);
		else {
			const surah = Number(job.key.split(":")[1]);
			get().startSurah(reciter, surah);
		}
	},
	clearReciter: async (reciter) => {
		controllers.get(get().job?.key ?? "")?.abort();
		await idbDeletePrefix("audio", `${reciter}:`);
		const audioSaved = { ...useApp.getState().audioSaved };
		for (const key of Object.keys(audioSaved)) if (key.startsWith(`${reciter}:`)) delete audioSaved[key];
		useApp.getState().patch({ audioSaved });
		set({ job: null });
	}
}));
async function startJob(reciter, plan, label, set, get) {
	const prev = get().job;
	if (prev) controllers.get(prev.key)?.abort();
	const meta = await loadMeta();
	const total = plan.reduce((sum, item) => {
		const ayahs = meta.surahs[item.surah - 1]?.ayahs ?? 0;
		return sum + Math.max(0, ayahs - item.from + 1);
	}, 0);
	if (total === 0) {
		useApp.getState().showToast("هذه التلاوة محفوظة بالفعل");
		return;
	}
	const key = label === "كل السور" ? `${reciter}:all` : `${reciter}:${plan[0]?.surah ?? 0}`;
	const ctrl = new AbortController();
	controllers.set(key, ctrl);
	set({ job: {
		key,
		label,
		done: 0,
		total,
		bytes: 0,
		paused: false,
		error: ""
	} });
	try {
		for (const item of plan) {
			const ayahs = meta.surahs[item.surah - 1]?.ayahs ?? 0;
			if (item.from > ayahs) continue;
			await runRange(reciter, item.surah, item.from, ctrl.signal, (bytes) => {
				const job = get().job;
				if (!job || job.key !== key) return;
				set({ job: {
					...job,
					done: job.done + 1,
					bytes: job.bytes + bytes
				} });
			});
		}
		set({ job: null });
		useApp.getState().showToast("اكتمل التنزيل");
	} catch (error) {
		if (ctrl.signal.aborted) return;
		const job = get().job;
		if (!job) return;
		set({ job: {
			...job,
			paused: true,
			error: error instanceof Error ? error.message : "توقف التنزيل"
		} });
	} finally {
		controllers.delete(key);
	}
}
//#endregion
export { useDownloads as t };
