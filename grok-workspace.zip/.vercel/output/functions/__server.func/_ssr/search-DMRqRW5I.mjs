import { i as __toESM } from "../_runtime.mjs";
import { c as loadNorm, d as loadTranslation, f as normalizeArabic, g as toArabicDigits, h as surahLabel, p as parseDigits, s as loadMeta, u as loadTafsir } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Screen, r as TopBar, t as Empty } from "./bits-D0fV6Dye.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-DMRqRW5I.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const meta = useQuery({
		queryKey: ["meta"],
		queryFn: loadMeta
	});
	const [q, setQ] = (0, import_react.useState)("");
	const [scope, setScope] = (0, import_react.useState)("quran");
	const [hits, setHits] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const history = useApp((s) => s.searchHistory);
	const pushSearch = useApp((s) => s.pushSearch);
	const run = async (query) => {
		const raw = query.trim();
		if (!raw || !meta.data) return;
		pushSearch(raw);
		setBusy(true);
		setNote("");
		const found = [];
		const numeric = parseDigits(raw).match(/^(\d+)\s*[:/]\s*(\d+)$/);
		if (numeric) {
			const s = Number(numeric[1]);
			const a = Number(numeric[2]);
			const info = meta.data.surahs[s - 1];
			if (info && a >= 1 && a <= info.ayahs) found.push({
				s,
				a,
				preview: "انتقال برقم الآية",
				where: "رقم"
			});
		}
		try {
			if (scope === "quran") {
				const norm = await loadNorm();
				const needle = normalizeArabic(raw);
				if (needle) norm.forEach((rows, si) => {
					rows.forEach((row, ai) => {
						if (found.length < 40 && row.includes(needle)) found.push({
							s: si + 1,
							a: ai + 1,
							preview: row,
							where: "المصحف"
						});
					});
				});
			} else if (scope === "tafsir") {
				const needle = normalizeArabic(raw);
				for (let s = 1; s <= 114 && found.length < 30; s++) (await loadTafsir(s)).forEach((row, ai) => {
					if (found.length < 30 && normalizeArabic(row).includes(needle)) found.push({
						s,
						a: ai + 1,
						preview: row.slice(0, 160),
						where: "التفسير"
					});
				});
			} else {
				const rows = await loadTranslation(scope);
				const needle = raw.toLowerCase();
				rows.forEach((surahRows, si) => {
					surahRows.forEach((row, ai) => {
						if (found.length < 40 && row.toLowerCase().includes(needle)) found.push({
							s: si + 1,
							a: ai + 1,
							preview: row.slice(0, 180),
							where: scope === "en" ? "الإنجليزية" : "الهولندية"
						});
					});
				});
			}
			setHits(found);
			if (!found.length) setNote("لا توجد نتائج في المحتوى المحفوظ على الجهاز.");
		} catch {
			setNote("تعذر البحث. افتح الإعدادات واحفظ النصوص أثناء الاتصال ثم أعد المحاولة دون إنترنت.");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "البحث",
		backTo: "/more"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					run(q);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "كلمة، أو ٢:٢٥٥",
					className: "min-w-0 flex-1 rounded-card border border-line bg-surface px-4 py-3 outline-none"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "gold-btn px-4",
					disabled: busy,
					children: busy ? "…" : "ابحث"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					["quran", "المصحف"],
					["tafsir", "التفسير"],
					["en", "الإنجليزية"],
					["nl", "الهولندية"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `ghost-btn ${scope === id ? "border-gold text-gold" : ""}`,
					onClick: () => setScope(id),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "البحث محلي داخل النصوص المخزنة، ولا يُرسل إلى خادم."
			}),
			history.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ghost-btn",
					onClick: () => {
						setQ(item);
						run(item);
					},
					children: item
				}, item))
			}) : null,
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: note }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/mushaf/$surah",
					params: { surah: String(hit.s) },
					search: { ayah: hit.a },
					className: "card block p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-gold",
						children: [
							meta.data ? surahLabel(meta.data.surahs[hit.s - 1]?.name ?? "") : "",
							" · ",
							toArabicDigits(hit.a),
							" · ",
							hit.where
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 line-clamp-3 text-sm leading-relaxed",
						children: hit.preview
					})]
				}) }, `${hit.where}-${hit.s}-${hit.a}-${hit.preview.slice(0, 12)}`))
			})
		]
	})] });
}
//#endregion
export { SearchPage as component };
