import { i as __toESM } from "../_runtime.mjs";
import { g as toArabicDigits, l as loadSurah } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
import { t as CATEGORIES } from "./adhkar-DXMdix4g.mjs";
import { r as Route$1 } from "./router-Bl5MT34k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/adhkar._id-C6VgND1H.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DhikrList() {
	const { id } = Route$1.useParams();
	const category = CATEGORIES.find((item) => item.id === id);
	if (!category) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "الأذكار",
		backTo: "/adhkar"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, { children: "هذا القسم غير موجود." })] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: category.title,
		backTo: "/adhkar"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		className: "space-y-3",
		children: category.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DhikrCard, { item }, item.id))
	})] });
}
function DhikrCard({ item }) {
	const count = useApp((s) => s.dhikrCounts[item.id] ?? 0);
	const setDhikr = useApp((s) => s.setDhikr);
	const toggle = useApp((s) => s.toggleFav);
	const has = useApp((s) => s.hasFav);
	const done = count >= item.repeat;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "card p-4",
		children: [
			item.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 text-sm text-gold",
				children: item.title
			}) : null,
			item.ref ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuranDhikr, {
				s: item.ref.s,
				a: item.ref.a,
				a2: item.ref.a2
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "quran-text text-2xl leading-loose",
				children: item.text
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs leading-relaxed text-muted",
				children: item.source
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: `mt-3 flex h-28 w-full flex-col items-center justify-center rounded-card border ${done ? "border-gold bg-gold text-cream-ink" : "border-gold/50 bg-surface-2"}`,
				onClick: () => setDhikr(item.id, Math.min(item.repeat, count + 1)),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-3xl font-bold",
					children: [
						toArabicDigits(count),
						" / ",
						toArabicDigits(item.repeat)
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm",
					children: done ? "تم" : "اضغط للعد"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ghost-btn",
					onClick: () => setDhikr(item.id, 0),
					children: "إعادة العداد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ghost-btn",
					onClick: () => toggle({
						kind: "dhikr",
						id: item.id
					}),
					children: has({
						kind: "dhikr",
						id: item.id
					}) ? "في المفضلة" : "حفظ"
				})]
			})
		]
	});
}
function QuranDhikr({ s, a, a2 }) {
	const q = useQuery({
		queryKey: ["surah", s],
		queryFn: () => loadSurah(s)
	});
	const [text, setText] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!q.data) return;
		const parts = q.data.ayahs.filter((ayah) => ayah.a >= a && ayah.a <= (a2 ?? a)).map((ayah) => ayah.t);
		setText(parts.join(" "));
	}, [
		q.data,
		a,
		a2
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "quran-text text-2xl leading-loose",
		children: text || "…"
	});
}
//#endregion
export { DhikrList as component };
