import { g as toArabicDigits, h as surahLabel, s as loadMeta } from "./quran-DVrhwAzv.mjs";
import { i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { a as reciterName } from "./reciters-BvKEdjn7.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Screen, r as TopBar, t as Empty } from "./bits-D0fV6Dye.mjs";
import { n as findDhikr } from "./adhkar-DXMdix4g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/favorites-BQMdKvU7.js
var import_jsx_runtime = require_jsx_runtime();
function FavoritesPage() {
	const favs = useApp((s) => s.favorites);
	const toggle = useApp((s) => s.toggleFav);
	const meta = useQuery({
		queryKey: ["meta"],
		queryFn: loadMeta
	});
	const name = (s) => meta.data ? surahLabel(meta.data.surahs[s - 1]?.name ?? "") : `سورة ${s}`;
	const groups = [
		{
			title: "سور",
			items: favs.filter((f) => f.kind === "surah")
		},
		{
			title: "آيات",
			items: favs.filter((f) => f.kind === "ayah")
		},
		{
			title: "تلاوات",
			items: favs.filter((f) => f.kind === "audio")
		},
		{
			title: "أذكار",
			items: favs.filter((f) => f.kind === "dhikr")
		},
		{
			title: "تفسيرات",
			items: favs.filter((f) => f.kind === "tafsir")
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "المفضلة",
		backTo: "/more"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		className: "space-y-4",
		children: [favs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "لا توجد عناصر محفوظة بعد. الحفظ يبقى على هذا الجهاز دون حساب." }) : null, groups.map((group) => group.items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-2 font-bold text-gold",
			children: group.title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: group.items.map((item, index) => {
				if (item.kind === "surah") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					onRemove: () => toggle(item),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/mushaf/$surah",
						params: { surah: String(item.s) },
						search: { ayah: 1 },
						children: name(item.s)
					})
				}, index);
				if (item.kind === "ayah" || item.kind === "tafsir") {
					const href = item.kind === "tafsir" ? null : true;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						onRemove: () => toggle(item),
						children: href ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/mushaf/$surah",
							params: { surah: String(item.s) },
							search: { ayah: item.a },
							children: [
								name(item.s),
								" · ",
								toArabicDigits(item.a)
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/tafsir",
							search: {
								s: item.s,
								a: item.a
							},
							children: [
								name(item.s),
								" · ",
								toArabicDigits(item.a)
							]
						})
					}, index);
				}
				if (item.kind === "audio") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					onRemove: () => toggle(item),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/listen",
						children: [
							name(item.s),
							" · ",
							reciterName(item.reciter)
						]
					})
				}, index);
				const dhikr = findDhikr(item.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					onRemove: () => toggle(item),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/adhkar/$id",
						params: { id: dhikr?.category.id ?? "morning" },
						children: dhikr?.item.title || dhikr?.item.text?.slice(0, 42) || item.id
					})
				}, index);
			})
		})] }, group.title) : null)]
	})] });
}
function Row({ children, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "card flex items-center justify-between gap-3 px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 flex-1 font-semibold",
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "text-sm text-muted",
			onClick: onRemove,
			children: "إزالة"
		})]
	});
}
//#endregion
export { FavoritesPage as component };
