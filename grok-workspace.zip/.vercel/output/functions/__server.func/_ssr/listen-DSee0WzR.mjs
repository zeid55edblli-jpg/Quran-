import { i as __toESM } from "../_runtime.mjs";
import { g as toArabicDigits, h as surahLabel, s as loadMeta } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { a as reciterName, i as formatBytes, r as estimateBytes, t as RECITERS } from "./reciters-BvKEdjn7.mjs";
import { a as Square, d as Pause, n as Trash2, u as Play, v as Download } from "../_libs/lucide-react.mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
import { t as useDownloads } from "./downloads-B-ZClEDz.mjs";
import { n as setPlaybackRate, r as usePlayer } from "./player-D4zMIWHV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/listen-DSee0WzR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ListenPage() {
	const meta = useQuery({
		queryKey: ["meta"],
		queryFn: loadMeta
	});
	const reciter = useApp((s) => s.reciter);
	const rate = useApp((s) => s.rate);
	const repeat = useApp((s) => s.repeat);
	const saved = useApp((s) => s.audioSaved);
	const patch = useApp((s) => s.patch);
	const toggleFav = useApp((s) => s.toggleFav);
	const hasFav = useApp((s) => s.hasFav);
	const player = usePlayer();
	const job = useDownloads((s) => s.job);
	const startSurah = useDownloads((s) => s.startSurah);
	const startAll = useDownloads((s) => s.startAll);
	const pause = useDownloads((s) => s.pause);
	const resume = useDownloads((s) => s.resume);
	const clearReciter = useDownloads((s) => s.clearReciter);
	const [confirmAll, setConfirmAll] = (0, import_react.useState)(false);
	const [filter, setFilter] = (0, import_react.useState)("");
	const surahs = (meta.data?.surahs ?? []).filter((s) => {
		const needle = filter.trim();
		if (!needle) return true;
		return surahLabel(s.name).includes(needle) || String(s.n) === needle;
	});
	const allEstimate = estimateBytes(6236);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: "الاستماع",
			backTo: "/"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "القارئ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex gap-2 overflow-x-auto pb-1",
							children: RECITERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `shrink-0 rounded-full px-3 py-2 text-sm ${reciter === item.id ? "bg-gold font-bold text-cream-ink" : "bg-surface-2 text-fg"}`,
								onClick: () => patch({ reciter: item.id }),
								children: item.name
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs leading-relaxed text-muted",
							children: [
								"التلاوة صوت حقيقي من شبكة Islamic Network بجودة ٦٤. لا تُخزَّن داخل التطبيق ابتداءً بسبب الحجم وحقوق التسجيلات. بعد التنزيل تُحفظ على هذا الجهاز وتُشغَّل دون إنترنت. التقدير التقريبي للقارئ كاملًا: ",
								formatBytes(allEstimate),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "gold-btn",
								onClick: () => setConfirmAll(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 16 }), " تنزيل كل السور"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "ghost-btn",
								onClick: () => void clearReciter(reciter),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 16 }), " حذف تلاوات هذا القارئ"]
							})]
						}),
						job ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm",
									children: [
										"تنزيل ",
										job.label,
										": ",
										toArabicDigits(job.done),
										" / ",
										toArabicDigits(job.total),
										" · ",
										formatBytes(job.bytes)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 h-2 overflow-hidden rounded-full bg-surface-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-gold",
										style: { width: `${job.total ? job.done / job.total * 100 : 0}%` }
									})
								}),
								job.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-danger",
									children: job.error
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex gap-2",
									children: job.paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "ghost-btn",
										onClick: resume,
										children: "استكمال"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "ghost-btn",
										onClick: pause,
										children: "إيقاف التنزيل"
									})
								})
							]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: player.surah ? reciterName(reciter) : "لم يبدأ التشغيل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold",
								children: player.surah && meta.data ? `${surahLabel(meta.data.surahs[player.surah - 1]?.name ?? "")} · الآية ${toArabicDigits(player.ayah)}` : "اختر سورة"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "gold-btn h-12 w-12 px-0",
								"aria-label": "تشغيل أو إيقاف",
								onClick: () => player.toggle(),
								disabled: !player.surah,
								children: player.playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "mt-3 w-full accent-gold",
							type: "range",
							min: 0,
							max: 1e3,
							value: player.duration ? Math.round(player.current / player.duration * 1e3) : 0,
							onChange: (e) => player.seek(Number(e.target.value) / 1e3),
							"aria-label": "موضع الاستماع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "ghost-btn",
									onClick: () => void player.prev(),
									children: "السابقة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "ghost-btn",
									onClick: () => void player.next(),
									children: "التالية"
								}),
								[
									.75,
									1,
									1.25,
									1.5,
									2
								].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `ghost-btn ${rate === value ? "border-gold text-gold" : ""}`,
									onClick: () => {
										patch({ rate: value });
										setPlaybackRate(value);
									},
									children: [value, "×"]
								}, value))
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex gap-2",
							children: [
								["off", "دون تكرار"],
								["ayah", "تكرار الآية"],
								["surah", "تكرار السورة"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `ghost-btn ${repeat === id ? "border-gold text-gold" : ""}`,
								onClick: () => patch({ repeat: id }),
								children: label
							}, id))
						}),
						player.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-danger",
							children: player.error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "يستمر الصوت عند الانتقال بين الصفحات. أزرار قفل الشاشة تعتمد على دعم المتصفح."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: filter,
					onChange: (e) => setFilter(e.target.value),
					placeholder: "ابحث عن سورة",
					className: "w-full rounded-card border border-line bg-surface px-4 py-3 outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: surahs.map((s) => {
						const count = saved[`${reciter}:${s.n}`] ?? 0;
						const active = player.surah === s.n;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "card flex items-center gap-2 px-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "icon-btn",
									"aria-label": active && player.playing ? "إيقاف" : "تشغيل",
									onClick: () => {
										if (active && player.playing) player.toggle();
										else player.play(s.n, active ? player.ayah : 1);
									},
									children: active && player.playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 18 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate font-semibold",
										children: [
											toArabicDigits(s.n),
											". ",
											surahLabel(s.name)
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: count >= s.ayahs ? "محفوظة دون إنترنت" : count > 0 ? `تنزيل جزئي ${toArabicDigits(count)}/${toArabicDigits(s.ayahs)}` : `غير محفوظة · حوالي ${formatBytes(estimateBytes(s.ayahs))}`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "ghost-btn px-3",
									onClick: () => startSurah(reciter, s.n),
									"aria-label": "تنزيل السورة",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 16 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: `text-xs ${hasFav({
										kind: "audio",
										s: s.n,
										reciter
									}) ? "text-gold" : "text-muted"}`,
									onClick: () => toggleFav({
										kind: "audio",
										s: s.n,
										reciter
									}),
									children: "مفضلة"
								})
							]
						}, s.n);
					})
				})
			]
		}),
		confirmAll ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-4",
			role: "dialog",
			"aria-modal": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card w-full max-w-lg space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-bold",
						children: [
							"تنزيل كل سور ",
							reciterName(reciter),
							"؟"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm leading-relaxed text-muted",
						children: [
							"الحجم التقريبي ",
							formatBytes(allEstimate),
							". يُحفظ على هذا الجهاز ويمكن إيقافه واستكماله. لا يبدأ التنزيل إلا بعد موافقتك، ويحتاج اتصالًا."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "gold-btn flex-1",
							onClick: () => {
								setConfirmAll(false);
								startAll(reciter);
							},
							children: "ابدأ التنزيل"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "ghost-btn flex-1",
							onClick: () => setConfirmAll(false),
							children: "إلغاء"
						})]
					})
				]
			})
		}) : null
	] });
}
//#endregion
export { ListenPage as component };
