import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-uEI-cFJD.js
function sameFav(a, b) {
	if (a.kind !== b.kind) return false;
	if (a.kind === "dhikr" && b.kind === "dhikr") return a.id === b.id;
	if (a.kind === "surah" && b.kind === "surah") return a.s === b.s;
	if (a.kind === "audio" && b.kind === "audio") return a.s === b.s && a.reciter === b.reciter;
	if ("a" in a && "a" in b) return a.s === b.s && a.a === b.a;
	return false;
}
var toastTimer;
var useApp = create()(persist((set, get) => ({
	seenSplash: false,
	appearance: "night",
	mushafTheme: "day",
	fontScale: 1,
	translation: "off",
	reciter: "ar.alafasy",
	rate: 1,
	repeat: "off",
	reminders: {
		read: {
			enabled: false,
			time: "08:00"
		},
		morning: {
			enabled: false,
			time: "06:30"
		},
		evening: {
			enabled: false,
			time: "17:30"
		},
		resume: {
			enabled: false,
			time: "21:00"
		}
	},
	reminderStamp: "",
	searchHistoryOn: true,
	searchHistory: [],
	lastRead: null,
	lastListen: null,
	favorites: [],
	audioSaved: {},
	place: null,
	dhikrCounts: {},
	toast: "",
	markSplash: () => set({ seenSplash: true }),
	patch: (partial) => set(partial),
	setLastRead: (pos) => set({ lastRead: pos }),
	setLastListen: (pos) => set({ lastListen: pos }),
	toggleFav: (fav) => {
		const list = get().favorites;
		set({ favorites: list.some((item) => sameFav(item, fav)) ? list.filter((item) => !sameFav(item, fav)) : [fav, ...list] });
	},
	hasFav: (fav) => get().favorites.some((item) => sameFav(item, fav)),
	pushSearch: (q) => {
		const query = q.trim();
		if (!query || !get().searchHistoryOn) return;
		set({ searchHistory: [query, ...get().searchHistory.filter((item) => item !== query)].slice(0, 12) });
	},
	clearSearch: () => set({ searchHistory: [] }),
	setAudioSaved: (key, count) => set({ audioSaved: {
		...get().audioSaved,
		[key]: count
	} }),
	setDhikr: (id, count) => set({ dhikrCounts: {
		...get().dhikrCounts,
		[id]: count
	} }),
	showToast: (message) => {
		set({ toast: message });
		if (toastTimer) clearTimeout(toastTimer);
		toastTimer = setTimeout(() => set({ toast: "" }), 1800);
	}
}), {
	name: "noor-al-quran",
	partialize: (state) => ({
		seenSplash: state.seenSplash,
		appearance: state.appearance,
		mushafTheme: state.mushafTheme,
		fontScale: state.fontScale,
		translation: state.translation,
		reciter: state.reciter,
		rate: state.rate,
		repeat: state.repeat,
		reminders: state.reminders,
		reminderStamp: state.reminderStamp,
		searchHistoryOn: state.searchHistoryOn,
		searchHistory: state.searchHistory,
		lastRead: state.lastRead,
		lastListen: state.lastListen,
		favorites: state.favorites,
		audioSaved: state.audioSaved,
		place: state.place,
		dhikrCounts: state.dhikrCounts
	})
}));
//#endregion
export { useApp as t };
