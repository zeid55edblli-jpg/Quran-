import { i as __toESM } from "../_runtime.mjs";
import { f as normalizeArabic, g as toArabicDigits, h as surahLabel, s as loadMeta } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mushaf-b8zvLIp-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MushafIndex() {
	const meta = useQuery({
		queryKey: ["meta"],
		queryFn: loadMeta
	});
	const [tab, setTab] = (0, import_react.useState)("surah");
	const [q, setQ] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)("1");
	const fav = useApp((s) => s.favorites);
	const toggle = useApp((s) => s.toggleFav);
	const has = useApp((s) => s.hasFav);
	const surahs = (0, import_react.useMemo)(() => {
		const list = meta.data?.surahs ?? [];
		const needle = normalizeArabic(q);
		if (!needle) return list;
		return list.filter((s) => normalizeArabic(s.name).includes(needle) || s.en.toLowerCase().includes(q.toLowerCase()) || String(s.n) === q.trim());
	}, [meta.data, q]);
	const jumpPage = () => {
		const n = Number(page);
		if (!meta.data || n < 1 || n > 604) return null;
		return meta.data.pages[n - 1];
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "المصحف الشريف",
		backTo: "/"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex rounded-full bg-surface p-1",
			children: [
				["surah", "السور"],
				["juz", "الأجزاء"],
				["page", "الصفحات"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `min-h-11 flex-1 rounded-full text-sm font-semibold ${tab === id ? "bg-gold text-cream-ink" : "text-muted"}`,
				onClick: () => setTab(id),
				children: label
			}, id))
		}),
		tab === "surah" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: q,
			onChange: (e) => setQ(e.target.value),
			placeholder: "ابحث باسم السورة",
			className: "mb-3 w-full rounded-card border border-line bg-surface px-4 py-3 outline-none"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: surahs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "card flex items-center gap-3 px-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex h-10 w-10 items-center justify-center rounded-full border border-gold text-sm font-bold text-gold",
						children: toArabicDigits(s.n)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/mushaf/$surah",
						params: { surah: String(s.n) },
						search: { ayah: 1 },
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-bold",
							children: surahLabel(s.name)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								s.type === "makki" ? "مكية" : "مدنية",
								" · ",
								toArabicDigits(s.ayahs),
								" آية · ",
								s.en
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `text-sm ${has({
							kind: "surah",
							s: s.n
						}) ? "text-gold" : "text-muted"}`,
						onClick: () => toggle({
							kind: "surah",
							s: s.n
						}),
						children: has({
							kind: "surah",
							s: s.n
						}) ? "محفوظة" : "حفظ"
					})
				]
			}, s.n))
		})] }) : null,
		tab === "juz" && meta.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid grid-cols-2 gap-2",
			children: meta.data.juz.map(([s, a], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/mushaf/$surah",
				params: { surah: String(s) },
				search: { ayah: a },
				className: "card block px-3 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-bold text-gold",
					children: ["الجزء ", toArabicDigits(index + 1)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						surahLabel(meta.data.surahs[s - 1]?.name ?? ""),
						" · ",
						toArabicDigits(a)
					]
				})]
			}) }, index))
		}) : null,
		tab === "page" && meta.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "card space-y-3 p-4",
			onSubmit: (e) => {
				e.preventDefault();
				const target = jumpPage();
				if (!target) return;
				const anchor = document.getElementById("page-go");
				anchor?.setAttribute("data-s", String(target[0]));
				anchor?.setAttribute("data-a", String(target[1]));
				anchor?.click();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "المصحف ٦٠٤ صفحات. أدخل رقم الصفحة للانتقال إلى أول آية فيها."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					inputMode: "numeric",
					value: page,
					onChange: (e) => setPage(e.target.value.replace(/[^\d]/g, "").slice(0, 3)),
					className: "w-full rounded-card border border-line bg-bg px-4 py-3 text-center text-2xl outline-none"
				}),
				(() => {
					const target = jumpPage();
					if (!target) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: "أدخل رقمًا من ١ إلى ٦٠٤"
					});
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						id: "page-go",
						to: "/mushaf/$surah",
						params: { surah: String(target[0]) },
						search: { ayah: target[1] },
						className: "gold-btn w-full",
						children: ["انتقل إلى الصفحة ", toArabicDigits(page)]
					});
				})(),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "الأحزاب: كل جزء حزبان، وكل حزب أربعة أرباع. رقم الربع يظهر داخل صفحة القراءة."
				})
			]
		}) : null,
		fav.length === 0 ? null : null
	] })] });
}
//#endregion
export { MushafIndex as component };
