import { i as __toESM } from "../_runtime.mjs";
import { g as toArabicDigits, h as surahLabel, l as loadSurah, s as loadMeta, u as loadTafsir } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as Heart, o as Share2, y as Copy } from "../_libs/lucide-react.mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
import { i as Route$3 } from "./router-Bl5MT34k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tafsir-Uvqb09E_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TafsirPage() {
	const search = Route$3.useSearch();
	const [surah, setSurah] = (0, import_react.useState)(search.s);
	const [ayah, setAyah] = (0, import_react.useState)(search.a);
	const meta = useQuery({
		queryKey: ["meta"],
		queryFn: loadMeta
	});
	const q = useQuery({
		queryKey: ["surah", surah],
		queryFn: () => loadSurah(surah)
	});
	const tf = useQuery({
		queryKey: ["tf", surah],
		queryFn: () => loadTafsir(surah)
	});
	const scale = useApp((s) => s.fontScale);
	const patch = useApp((s) => s.patch);
	const toggle = useApp((s) => s.toggleFav);
	const has = useApp((s) => s.hasFav);
	const info = meta.data?.surahs[surah - 1];
	const safeAyah = info ? Math.min(Math.max(1, ayah), info.ayahs) : ayah;
	const text = q.data?.ayahs[safeAyah - 1]?.t ?? "";
	const explanation = tf.data?.[safeAyah - 1] ?? "";
	const bundle = `${text}\n\n${explanation}\n\n${meta.data?.tafsirSource ?? ""}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "التفسير",
		backTo: "/more"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted",
				children: meta.data?.tafsirSource
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["السورة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-card border border-line bg-surface px-3 py-3",
						value: surah,
						onChange: (e) => {
							setSurah(Number(e.target.value));
							setAyah(1);
						},
						children: meta.data?.surahs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: s.n,
							children: [
								toArabicDigits(s.n),
								" ",
								surahLabel(s.name)
							]
						}, s.n))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["الآية", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "numeric",
						className: "mt-1 w-full rounded-card border border-line bg-surface px-3 py-3",
						value: ayah,
						onChange: (e) => setAyah(Number(e.target.value.replace(/[^\d]/g, "")) || 1)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: () => patch({ fontScale: Math.max(.85, scale - .1) }),
						children: "خط أصغر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: () => patch({ fontScale: Math.min(1.7, scale + .1) }),
						children: "خط أكبر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/mushaf/$surah",
						params: { surah: String(surah) },
						search: { ayah: safeAyah },
						className: "ghost-btn",
						children: "في المصحف"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "mushaf-day rounded-card p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "quran-text",
					style: { fontSize: `${1.45 * scale}rem` },
					children: [
						text || "…",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ayah-mark",
							children: toArabicDigits(safeAyah)
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "card p-4 leading-relaxed",
				style: { fontSize: `${scale}rem` },
				children: tf.isError ? "تعذر فتح التفسير. احفظ المحتوى للجهاز من الإعدادات أثناء الاتصال." : explanation || "…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: () => void navigator.clipboard.writeText(bundle).then(() => useApp.getState().showToast("تم النسخ")),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { size: 16 }), " نسخ"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: () => {
							if (navigator.share) navigator.share({
								title: "التفسير الميسر",
								text: bundle
							}).catch(() => void 0);
							else navigator.clipboard.writeText(bundle);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { size: 16 }), " مشاركة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ghost-btn",
						onClick: () => toggle({
							kind: "tafsir",
							s: surah,
							a: safeAyah
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { size: 16 }),
							" ",
							has({
								kind: "tafsir",
								s: surah,
								a: safeAyah
							}) ? "محفوظ" : "حفظ التفسير"
						]
					})
				]
			})
		]
	})] });
}
//#endregion
export { TafsirPage as component };
