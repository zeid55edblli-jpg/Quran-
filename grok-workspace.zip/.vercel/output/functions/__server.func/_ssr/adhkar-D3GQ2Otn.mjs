import { g as toArabicDigits } from "./quran-DVrhwAzv.mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
import { t as CATEGORIES } from "./adhkar-DXMdix4g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/adhkar-D3GQ2Otn.js
var import_jsx_runtime = require_jsx_runtime();
function AdhkarPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "الأدعية والأذكار",
		backTo: "/more"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "الآيات تُعرض من المصحف المضمّن. الأذكار النبوية من الصحيحين والسنن مع مصدر كل ذكر. لا يُنسب حديث إلى غير مصدره المذكور."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: CATEGORIES.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/adhkar/$id",
				params: { id: category.id },
				className: "card block p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: category.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: category.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-gold",
						children: [toArabicDigits(category.items.length), " أذكار"]
					})
				]
			}) }, category.id))
		})]
	})] });
}
//#endregion
export { AdhkarPage as component };
