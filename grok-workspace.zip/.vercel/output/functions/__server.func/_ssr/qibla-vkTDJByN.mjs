import { i as __toESM } from "../_runtime.mjs";
import { g as toArabicDigits } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { n as Screen, r as TopBar } from "./bits-D0fV6Dye.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qibla-vkTDJByN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KAABA_LAT = 21.4225;
var KAABA_LON = 39.8262;
function qiblaBearing(lat, lon) {
	const φ1 = lat * Math.PI / 180;
	const λ1 = lon * Math.PI / 180;
	const φ2 = KAABA_LAT * Math.PI / 180;
	const λ2 = KAABA_LON * Math.PI / 180;
	const y = Math.sin(λ2 - λ1) * Math.cos(φ2);
	const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(λ2 - λ1);
	return Math.atan2(y, x) * 180 / Math.PI;
}
function normalizeDeg(value) {
	return (value % 360 + 360) % 360;
}
var CITIES = [
	{
		name: "مكة المكرمة",
		lat: 21.4225,
		lon: 39.8262
	},
	{
		name: "المدينة المنورة",
		lat: 24.4672,
		lon: 39.6111
	},
	{
		name: "الرياض",
		lat: 24.7136,
		lon: 46.6753
	},
	{
		name: "جدة",
		lat: 21.5433,
		lon: 39.1728
	},
	{
		name: "الدمام",
		lat: 26.4207,
		lon: 50.0888
	},
	{
		name: "دبي",
		lat: 25.2048,
		lon: 55.2708
	},
	{
		name: "أبوظبي",
		lat: 24.4539,
		lon: 54.3773
	},
	{
		name: "الدوحة",
		lat: 25.2854,
		lon: 51.531
	},
	{
		name: "الكويت",
		lat: 29.3759,
		lon: 47.9774
	},
	{
		name: "المنامة",
		lat: 26.2235,
		lon: 50.5876
	},
	{
		name: "مسقط",
		lat: 23.588,
		lon: 58.3829
	},
	{
		name: "صنعاء",
		lat: 15.3694,
		lon: 44.191
	},
	{
		name: "عمّان",
		lat: 31.9539,
		lon: 35.9106
	},
	{
		name: "القدس",
		lat: 31.7683,
		lon: 35.2137
	},
	{
		name: "دمشق",
		lat: 33.5138,
		lon: 36.2765
	},
	{
		name: "بيروت",
		lat: 33.8938,
		lon: 35.5018
	},
	{
		name: "بغداد",
		lat: 33.3152,
		lon: 44.3661
	},
	{
		name: "القاهرة",
		lat: 30.0444,
		lon: 31.2357
	},
	{
		name: "الإسكندرية",
		lat: 31.2001,
		lon: 29.9187
	},
	{
		name: "الخرطوم",
		lat: 15.5007,
		lon: 32.5599
	},
	{
		name: "تونس",
		lat: 36.8065,
		lon: 10.1815
	},
	{
		name: "الجزائر",
		lat: 36.7538,
		lon: 3.0588
	},
	{
		name: "الرباط",
		lat: 34.0209,
		lon: -6.8416
	},
	{
		name: "طرابلس",
		lat: 32.8872,
		lon: 13.1913
	},
	{
		name: "إسطنبول",
		lat: 41.0082,
		lon: 28.9784
	},
	{
		name: "جاكرتا",
		lat: -6.2088,
		lon: 106.8456
	},
	{
		name: "كوالالمبور",
		lat: 3.139,
		lon: 101.6869
	},
	{
		name: "لندن",
		lat: 51.5074,
		lon: -.1278
	},
	{
		name: "أمستردام",
		lat: 52.3676,
		lon: 4.9041
	},
	{
		name: "باريس",
		lat: 48.8566,
		lon: 2.3522
	},
	{
		name: "نيويورك",
		lat: 40.7128,
		lon: -74.006
	}
];
function readHeading(event) {
	if (typeof event.webkitCompassHeading === "number" && !Number.isNaN(event.webkitCompassHeading)) return {
		deg: event.webkitCompassHeading,
		absolute: true
	};
	if (typeof event.alpha === "number" && event.absolute) return {
		deg: normalizeDeg(360 - event.alpha),
		absolute: true
	};
	if (typeof event.alpha === "number") return {
		deg: normalizeDeg(360 - event.alpha),
		absolute: false
	};
	return {
		deg: null,
		absolute: false
	};
}
function QiblaPage() {
	const place = useApp((s) => s.place);
	const patch = useApp((s) => s.patch);
	const [heading, setHeading] = (0, import_react.useState)({
		deg: null,
		absolute: false
	});
	const [sensorNote, setSensorNote] = (0, import_react.useState)("لم تُفعَّل البوصلة بعد.");
	const [lat, setLat] = (0, import_react.useState)(place ? String(place.lat) : "");
	const [lon, setLon] = (0, import_react.useState)(place ? String(place.lon) : "");
	const [manualError, setManualError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const onOrient = (event) => {
			const next = readHeading(event);
			if (next.deg == null) return;
			setHeading(next);
			setSensorNote(next.absolute ? "الاتجاه من مستشعر الجهاز." : "المستشعر نسبي وقد يحتاج معايرة، فلا يُعتمد عليه وحده.");
		};
		window.addEventListener("deviceorientationabsolute", onOrient);
		window.addEventListener("deviceorientation", onOrient);
		return () => {
			window.removeEventListener("deviceorientationabsolute", onOrient);
			window.removeEventListener("deviceorientation", onOrient);
		};
	}, []);
	const askSensor = async () => {
		const ctor = DeviceOrientationEvent;
		try {
			if (typeof ctor.requestPermission === "function") {
				if (await ctor.requestPermission() !== "granted") {
					setSensorNote("رُفض الإذن. يمكن معرفة الزاوية من الشمال دون تحريك البوصلة.");
					return;
				}
			}
			setSensorNote("حرّك الهاتف بشكل رقم ٨ بعيدًا عن المغناطيس إن اضطربت الإبرة.");
		} catch {
			setSensorNote("تعذر طلب إذن البوصلة في هذا المتصفح.");
		}
	};
	const askLocation = () => {
		if (!navigator.geolocation) {
			setSensorNote("الموقع غير متاح. اختر مدينة أو أدخل الإحداثيات.");
			return;
		}
		navigator.geolocation.getCurrentPosition((pos) => {
			patch({ place: {
				lat: pos.coords.latitude,
				lon: pos.coords.longitude,
				label: "موقعي"
			} });
			setLat(pos.coords.latitude.toFixed(4));
			setLon(pos.coords.longitude.toFixed(4));
		}, () => setSensorNote("تعذر تحديد الموقع. اختر المدينة يدويًا، والحساب بعدها محلي."), {
			enableHighAccuracy: true,
			timeout: 8e3
		});
	};
	const bearing = place ? normalizeDeg(qiblaBearing(place.lat, place.lon)) : null;
	const delta = bearing != null && heading.deg != null ? normalizeDeg(bearing - heading.deg) : null;
	const aligned = delta != null && (delta < 8 || delta > 352);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "اتجاه القبلة",
		backTo: "/more"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card flex flex-col items-center px-4 py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative h-64 w-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-0 rounded-full border-2 border-gold",
							style: { transform: heading.deg != null ? `rotate(${-heading.deg}deg)` : void 0 },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute left-1/2 top-2 -translate-x-1/2 text-sm font-bold text-gold",
									children: "ش"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute bottom-2 left-1/2 -translate-x-1/2 text-xs text-muted",
									children: "ج"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute left-2 top-1/2 -translate-y-1/2 text-xs text-muted",
									children: "غ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute right-2 top-1/2 -translate-y-1/2 text-xs text-muted",
									children: "ق"
								}),
								bearing != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute left-1/2 top-1/2 h-28 w-1 origin-bottom bg-gold",
									style: { transform: `translate(-50%, -100%) rotate(${bearing}deg)` }
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-center text-lg font-bold",
						children: bearing == null ? "حدد موقعك أولًا" : aligned ? "أنت باتجاه القبلة" : `القبلة على ${toArabicDigits(Math.round(bearing))}° من الشمال`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-center text-sm text-muted",
						children: sensorNote
					}),
					!heading.absolute && heading.deg != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-sm text-danger",
						children: "قد يوجد تداخل أو قراءة غير مطلقة. ابتعد عن المغناطيس وأعد المعايرة برسم رقم ٨ بالهاتف."
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "gold-btn flex-1",
					onClick: askLocation,
					children: "تحديد موقعي"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ghost-btn flex-1",
					onClick: () => void askSensor(),
					children: "تفعيل البوصلة"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["المدينة", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "mt-1 w-full rounded-card border border-line bg-surface px-3 py-3",
					value: place?.label ?? "",
					onChange: (e) => {
						const city = CITIES.find((item) => item.name === e.target.value);
						if (!city) return;
						patch({ place: {
							lat: city.lat,
							lon: city.lon,
							label: city.name
						} });
						setLat(String(city.lat));
						setLon(String(city.lon));
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "اختر مدينة"
					}), CITIES.map((city) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: city.name,
						children: city.name
					}, city.name))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "card space-y-2 p-4",
				onSubmit: (e) => {
					e.preventDefault();
					const la = Number(lat);
					const lo = Number(lon);
					if (!Number.isFinite(la) || !Number.isFinite(lo) || Math.abs(la) > 90 || Math.abs(lo) > 180) {
						setManualError("أدخل خط عرض بين -٩٠ و٩٠ وخط طول بين -١٨٠ و١٨٠.");
						return;
					}
					setManualError("");
					patch({ place: {
						lat: la,
						lon: lo,
						label: "إحداثيات يدوية"
					} });
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "أو أدخل الإحداثيات. الحساب محلي ولا يحتاج إنترنت بعد حفظ الموقع."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: lat,
							onChange: (e) => setLat(e.target.value),
							placeholder: "خط العرض",
							className: "rounded-card border border-line bg-bg px-3 py-3",
							dir: "ltr"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: lon,
							onChange: (e) => setLon(e.target.value),
							placeholder: "خط الطول",
							className: "rounded-card border border-line bg-bg px-3 py-3",
							dir: "ltr"
						})]
					}),
					manualError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: manualError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "ghost-btn w-full",
						children: "احسب من الإحداثيات"
					})
				]
			}),
			place ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-xs text-muted",
				children: [
					"الموقع المستخدم: ",
					place.label,
					" (",
					place.lat.toFixed(3),
					", ",
					place.lon.toFixed(3),
					")"
				]
			}) : null
		]
	})] });
}
//#endregion
export { QiblaPage as component };
