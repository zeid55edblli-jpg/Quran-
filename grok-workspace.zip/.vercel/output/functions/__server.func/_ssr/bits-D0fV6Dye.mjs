import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { x as ChevronRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bits-D0fV6Dye.js
var import_jsx_runtime = require_jsx_runtime();
function TopBar({ title, backTo, action }) {
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-bg/90 px-3 py-2 backdrop-blur",
		children: [
			backTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "icon-btn",
				"aria-label": "رجوع",
				onClick: () => {
					if (window.history.length > 1) navigate({ to: backTo });
					else navigate({ to: backTo });
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-11" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "flex-1 truncate text-center text-lg font-bold text-gold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex w-11 justify-end",
				children: action
			})
		]
	});
}
function Screen({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `px-4 py-4 ${className}`,
		children
	});
}
function Empty({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "card px-4 py-8 text-center text-sm text-muted",
		children: text
	});
}
//#endregion
export { Screen as n, TopBar as r, Empty as t };
