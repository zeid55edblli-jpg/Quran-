//#region node_modules/.nitro/vite/services/ssr/assets/reciters-BvKEdjn7.js
var RECITERS = [
	{
		id: "ar.alafasy",
		name: "مشاري راشد العفاسي"
	},
	{
		id: "ar.husary",
		name: "محمود خليل الحصري"
	},
	{
		id: "ar.abdulbasitmurattal",
		name: "عبد الباسط عبد الصمد"
	},
	{
		id: "ar.shaatree",
		name: "أبو بكر الشاطري"
	},
	{
		id: "ar.ahmedajamy",
		name: "أحمد بن علي العجمي"
	}
];
function reciterName(id) {
	return RECITERS.find((item) => item.id === id)?.name ?? id;
}
function audioUrl(reciter, globalAyah) {
	return `https://cdn.islamic.network/quran/audio/64/${reciter}/${globalAyah}.mp3`;
}
/** Rough size at 64 kbps, from sampled files. Not an exact byte count. */
function estimateBytes(ayahCount) {
	return ayahCount * 52e3;
}
function formatBytes(bytes) {
	if (bytes < 1048576) return `${Math.max(1, Math.round(bytes / 1024))} ك.ب`;
	return `${(bytes / 1048576).toFixed(bytes > 104857600 ? 0 : 1)} م.ب`;
}
//#endregion
export { reciterName as a, formatBytes as i, audioUrl as n, estimateBytes as r, RECITERS as t };
