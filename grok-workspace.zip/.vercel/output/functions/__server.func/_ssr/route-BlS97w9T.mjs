import { i as __toESM } from "../_runtime.mjs";
import { g as toArabicDigits, h as surahLabel, s as loadMeta } from "./quran-DVrhwAzv.mjs";
import { a as require_react, i as require_jsx_runtime, n as QueryClientProvider, r as useQueryClient } from "../_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./store-uEI-cFJD.mjs";
import { a as reciterName } from "./reciters-BvKEdjn7.mjs";
import { b as Link, g as Outlet, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as BookOpen, _ as Headphones, d as Pause, h as House, p as Menu, u as Play } from "../_libs/lucide-react.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as usePlayer, t as bindAudio } from "./player-D4zMIWHV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-BlS97w9T.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NAV = [
	{
		to: "/",
		label: "الرئيسية",
		icon: House,
		exact: true
	},
	{
		to: "/mushaf",
		label: "المصحف",
		icon: BookOpen,
		exact: false
	},
	{
		to: "/listen",
		label: "الاستماع",
		icon: Headphones,
		exact: false
	},
	{
		to: "/more",
		label: "المزيد",
		icon: Menu,
		exact: false
	}
];
function Splash() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const seen = useApp((s) => s.seenSplash);
	const mark = useApp((s) => s.markSplash);
	(0, import_react.useEffect)(() => {
		const finish = () => setHydrated(true);
		const unsub = useApp.persist.onFinishHydration(finish);
		if (useApp.persist.hasHydrated()) finish();
		return unsub;
	}, []);
	if (!hydrated || seen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 mx-auto flex max-w-lg flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/art/splash.jpg",
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-bg/30 via-bg/55 to-bg" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex flex-1 flex-col items-center justify-end px-6 pb-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/art/emblem.jpg",
						alt: "",
						className: "mb-4 h-24 w-24 rounded-full border border-gold object-cover shadow-lg"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm tracking-widest text-gold",
						children: "NOOR AL QURAN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-4xl font-bold text-gold",
						children: "نور القرآن الكريم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xl text-fg",
						children: "نور لقلبك"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted",
						children: "رفيقك في كل مكان"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "gold-btn mt-8 w-full",
						onClick: mark,
						children: "ابدأ الآن"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 text-sm text-muted",
						onClick: mark,
						children: "تخطي"
					})
				]
			})
		]
	});
}
function MiniPlayer() {
	const surah = usePlayer((s) => s.surah);
	const ayah = usePlayer((s) => s.ayah);
	const playing = usePlayer((s) => s.playing);
	const toggle = usePlayer((s) => s.toggle);
	const path = useRouterState({ select: (s) => s.location.pathname });
	const { data } = useMetaSafe();
	if (!surah || path.startsWith("/listen")) return null;
	const name = data ? surahLabel(data.surahs[surah - 1]?.name ?? "") : "التلاوة";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-16 z-30 mx-auto w-full max-w-lg px-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card flex items-center gap-3 px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "icon-btn",
				onClick: toggle,
				"aria-label": playing ? "إيقاف" : "تشغيل",
				children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/listen",
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-semibold",
					children: name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-xs text-muted",
					children: ["الآية ", toArabicDigits(ayah)]
				})]
			})]
		})
	});
}
function useMetaSafe() {
	const [data, setData] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		loadMeta().then(setData).catch(() => void 0);
	}, []);
	return { data };
}
function ReminderEngine() {
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const now = /* @__PURE__ */ new Date();
			const time = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
			const stamp = `${now.toDateString()} ${time}`;
			const state = useApp.getState();
			if (state.reminderStamp === stamp) return;
			const labels = {
				read: "تذكير بقراءة القرآن",
				morning: "تذكير بأذكار الصباح",
				evening: "تذكير بأذكار المساء",
				resume: "تذكير بمتابعة القراءة"
			};
			const hit = Object.keys(labels).find((key) => state.reminders[key].enabled && state.reminders[key].time === time);
			if (!hit) return;
			state.patch({ reminderStamp: stamp });
			state.showToast(labels[hit]);
			if (typeof Notification !== "undefined" && Notification.permission === "granted") new Notification("نور القرآن الكريم", { body: labels[hit] });
		};
		const id = window.setInterval(tick, 15e3);
		return () => window.clearInterval(id);
	}, []);
	return null;
}
function AppShell() {
	const appearance = useApp((s) => s.appearance);
	const toast = useApp((s) => s.toast);
	const path = useRouterState({ select: (s) => s.location.pathname });
	const queryClient = useQueryClient();
	const playing = usePlayer((s) => s.playing);
	const surah = usePlayer((s) => s.surah);
	(0, import_react.useEffect)(() => bindAudio(), []);
	(0, import_react.useEffect)(() => {
		if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => void 0);
	}, []);
	(0, import_react.useEffect)(() => {
		queryClient.prefetchQuery({
			queryKey: ["meta"],
			queryFn: loadMeta
		});
	}, [queryClient]);
	const pad = surah && !path.startsWith("/listen") ? "pb-36" : "pb-20";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `app-bg min-h-dvh text-fg ${appearance === "day" ? "theme-day" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mx-auto flex min-h-dvh w-full max-w-lg flex-col ${pad}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniPlayer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-lg border-t border-line bg-bg/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex",
					children: NAV.map((item) => {
						const active = item.exact ? path === item.to : path === item.to || path.startsWith(`${item.to}/`);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: `nav-item ${active ? "active" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 20 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
						}, item.to);
					})
				})
			}),
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-24 z-50 mx-auto w-fit max-w-lg rounded-full bg-surface-2 px-4 py-2 text-sm text-fg shadow",
				children: toast
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReminderEngine, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: playing ? reciterName(useApp.getState().reciter) : ""
			})
		]
	});
}
function AppLayout() {
	const [client] = (0, import_react.useState)(() => new QueryClient({ defaultOptions: { queries: {
		networkMode: "always",
		retry: 1,
		staleTime: Infinity,
		refetchOnWindowFocus: false
	} } }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {})
	});
}
//#endregion
export { AppLayout as component };
