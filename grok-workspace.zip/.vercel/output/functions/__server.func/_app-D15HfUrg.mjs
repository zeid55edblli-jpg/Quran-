import { g as toArabicDigits, h as surahLabel, s as loadMeta, t as dayOfYear } from "./_ssr/quran-DVrhwAzv.mjs";
import { i as require_jsx_runtime, t as useQuery } from "./_libs/react+tanstack__react-query.mjs";
import { t as useApp } from "./_ssr/store-uEI-cFJD.mjs";
import { a as reciterName } from "./_ssr/reciters-BvKEdjn7.mjs";
import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { C as BookOpen, _ as Headphones, b as Compass, c as Search, g as Heart, m as Languages, s as Settings, w as BookMarked } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-D15HfUrg.js
var import_jsx_runtime = require_jsx_runtime();
var TILES = [
	{
		to: "/mushaf",
		label: "المصحف الشريف",
		icon: BookOpen
	},
	{
		to: "/listen",
		label: "الاستماع",
		icon: Headphones
	},
	{
		to: "/tafsir",
		label: "التفسير",
		icon: BookMarked
	},
	{
		to: "/translate",
		label: "الترجمة",
		icon: Languages
	},
	{
		to: "/adhkar",
		label: "الأدعية والأذكار",
		icon: Heart
	},
	{
		to: "/qibla",
		label: "اتجاه القبلة",
		icon: Compass
	},
	{
		to: "/search",
		label: "البحث",
		icon: Search
	},
	{
		to: "/favorites",
		label: "المفضلة",
		icon: Heart
	}
];
function HomePage() {
	const meta = useQuery({
		queryKey: ["meta"],
		queryFn: loadMeta
	});
	const last = useApp((s) => s.lastRead);
	const listen = useApp((s) => s.lastListen);
	const daily = meta.data ? meta.data.daily[dayOfYear() % meta.data.daily.length] : null;
	const lastSurah = last && meta.data ? meta.data.surahs[last.s - 1] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3 px-4 pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/art/emblem.jpg",
						alt: "",
						className: "h-12 w-12 rounded-full border border-gold object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-gold",
							children: "Noor Al Quran"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-xl font-bold",
							children: "نور القرآن الكريم"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/settings",
						className: "icon-btn",
						"aria-label": "الإعدادات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative mx-4 mt-4 overflow-hidden rounded-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/art/splash.jpg",
						alt: "",
						className: "h-44 w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/75 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute inset-x-0 bottom-0 p-4 text-lg font-semibold",
						children: "القرآن الكريم، رفيقك في كل مكان"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 px-4 py-4",
				children: [
					meta.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "card px-4 py-3 text-sm text-danger",
						children: "تعذر فتح قاعدة المصحف على هذا الجهاز."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "آخر موضع قراءة"
						}), last && lastSurah ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-lg font-bold",
								children: surahLabel(lastSurah.name)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									"الآية ",
									toArabicDigits(last.a),
									" · الجزء ",
									toArabicDigits(last.j),
									" · الصفحة ",
									toArabicDigits(last.p)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/mushaf/$surah",
								params: { surah: String(last.s) },
								search: { ayah: last.a },
								className: "gold-btn mt-3 w-full",
								children: "متابعة القراءة"
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-semibold",
							children: "لم تبدأ القراءة بعد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/mushaf",
							className: "gold-btn mt-3 w-full",
							children: "افتح المصحف"
						})] })]
					}),
					listen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/listen",
						className: "card block p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "آخر استماع"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-semibold",
								children: [
									meta.data ? surahLabel(meta.data.surahs[listen.s - 1]?.name ?? "") : "السورة",
									" · الآية",
									" ",
									toArabicDigits(listen.a)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-gold",
								children: reciterName(listen.reciter)
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-gold",
									children: "الآية اليومية"
								}), daily ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/mushaf/$surah",
									params: { surah: String(daily.s) },
									search: { ayah: daily.a },
									className: "text-xs text-muted",
									children: [
										meta.data ? surahLabel(meta.data.surahs[daily.s - 1]?.name ?? "") : "",
										" · ",
										toArabicDigits(daily.a)
									]
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "quran-text mt-2 text-2xl",
								children: daily?.t ?? "…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: "من نص المصحف المضمّن، وتتبدل حسب اليوم. ليست نصًا مولدًا."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-3",
						children: TILES.map((tile) => {
							const Icon = tile.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: tile.to,
								className: "card flex min-h-24 flex-col justify-between p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-3 font-semibold",
									children: tile.label
								})]
							}, tile.to);
						})
					})
				]
			})
		]
	});
}
//#endregion
export { HomePage as component };
